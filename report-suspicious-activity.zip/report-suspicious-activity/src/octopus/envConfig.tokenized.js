(function (window) {
    window.__envConfig = window.__envConfig || {};

    // @lpl/core
    window.__envConfig.enableDebug = false; // boolean
    window.__envConfig.logLevel = 'error'; // debug, info, warn, or error
    window.__envConfig.logApiDomain = '#{DO.SVC.INT.WEBAPI.UTPAPP.10.serviceurl}';
  
    // @lpl/cw
    window.__envConfig.apiDomain = '#{DO.SVC.EXT.MULESOFT.VIP.10.serviceurl}';
    window.__envConfig.lplServicesDomain = '#{DO.SVC.EXT.LPLServices.10.serviceurl}';
    window.__envConfig.webApiDomain = '#{DO.SVC.INT.WEBAPI.UTPAPP.10.serviceurl}';
    window.__envConfig.cwLocalDomain = '';
    window.__envConfig.loginDomain = '#{DO.SVC.EXT.Login.10.serviceurl}';
    window.__envConfig.bpmDomain = ' #{DO.SVC.EXT.DataPowerF5.Ext.BPM.ClientWorks.10.serviceurl}';
  
    // application specific goes here
    window.__envConfig.appCustom = '#{MyApp.Custom.Value}';
    window.__envConfig.cwLocalDomain = `${location.protocol}//${location.host}`;

}(this));