(function (window) {
    window.__envConfig = window.__envConfig || {};

    // @lpl/core
    window.__envConfig.enableDebug = true;  // boolean
    window.__envConfig.logLevel = 'debug';  // debug, info, warn, or error
    window.__envConfig.logApiDomain = 'https://webapidvi.dev.lpl.com';
    
    // @lpl/cw
    window.__envConfig.apiDomain = 'https://apidvi.dev.lpl.com';
    window.__envConfig.lplServicesDomain = 'https://lplservicesdevint.lpl.com';
    window.__envConfig.webApiDomain = 'https://webapidvi.dev.lpl.com';
    window.__envConfig.cwLocalDomain = 'https://clientworksdevint.lpl.com';
    window.__envConfig.loginDomain = 'https://logindevint.lpl.com';
    window.__envConfig.bpmDomain = 'https://clientworksbpmdvi.dev.lpl.com';

    // application specific goes here
    window.__envConfig.appCustom = 'cool, custom variable!'
}(this));