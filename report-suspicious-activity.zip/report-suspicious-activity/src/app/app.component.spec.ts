import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { LwkThemes, LwkThemesEnum } from '@lpl/themes';
import { rest, logger, loggerApplicationCategoryEnum, loggerApplicationGroupEnum } from '@lpl/core';
import { AppComponent } from './app.component';

// Mocking the necessary modules globally
jest.mock('@lpl/themes', () => ({
  LwkThemes: {
    setTheme: jest.fn(),
  },
  LwkThemesEnum: {
    cwDefault: 'cwDefault',
  },
}));

describe('AppComponent', () => {
  let fixture: ComponentFixture<AppComponent>;
  let component: AppComponent;

  beforeEach(async () => {
    // Reset the module before each test
    TestBed.resetTestingModule();

    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [AppComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  it(`should have as title 'report-unusual-activity'`, () => {
    expect(component.title).toEqual('report-unusual-activity');
  });

  it('should call rest.config and LwkThemes.setTheme on ngOnInit', () => {
    // Mock logger as an object for this test case
    jest.mock('@lpl/core', () => ({
      rest: {
        config: jest.fn(),
      },
      logger: {
        init: jest.fn(),
      },
      loggerApplicationCategoryEnum: {
        homeOffice: 'homeOffice',
      },
      loggerApplicationGroupEnum: {
        clr: 'clr',
      },
    }));

    const restConfigSpy = jest.spyOn(rest, 'config');
    const setThemeSpy = jest.spyOn(LwkThemes, 'setTheme');
    const loggerInitSpy = jest.spyOn(logger, 'init');

    component.ngOnInit();

    expect(restConfigSpy).toHaveBeenCalledWith(true, true);
    expect(setThemeSpy).toHaveBeenCalledWith(LwkThemesEnum.cwDefault);
    expect(loggerInitSpy).toHaveBeenCalledWith(
      'ReportUnusualActivityWeb',
      loggerApplicationCategoryEnum.homeOffice,
      loggerApplicationGroupEnum.clr
    );
  });

  // it('should log an error if logger is not defined', () => {
  //   // Mock logger as null for this test case
  //   jest.mock('@lpl/core', () => ({
  //     rest: { config: jest.fn() },
  //     logger: null, // Ensure logger is null in this specific test
  //     loggerApplicationCategoryEnum: {
  //       homeOffice: 'homeOffice',
  //     },
  //     loggerApplicationGroupEnum: {
  //       clr: 'clr',
  //     },
  //   }));

  //   // Spy on console.error
  //   const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation();

  //   // Re-create the component with the new logger mock
  //   TestBed.resetTestingModule();
  //   TestBed.configureTestingModule({
  //     imports: [RouterTestingModule],
  //     declarations: [AppComponent],
  //   }).compileComponents();

  //   const newFixture = TestBed.createComponent(AppComponent);
  //   const newComponent = newFixture.componentInstance;

  //   newComponent.ngOnInit();
  //   expect(consoleErrorSpy).toHaveBeenCalledWith('Logger is not defined');
  //   consoleErrorSpy.mockRestore();
  // });

  it('should set title property correctly', () => {
    expect(component.title).toBe('report-unusual-activity');
  });
});
