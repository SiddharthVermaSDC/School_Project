import { TestBed } from '@angular/core/testing';
import {
  logger,
  loggerEventKindEnum,
  loggerEventOutcomeEnum,
  loggerEventTypeEnum,
  Guid,
} from '@lpl/core';
import { LoggerService } from './logger.service';

jest.mock('@lpl/core', () => ({
  logger: {
    info: jest.fn(),
    error: jest.fn(),
  },
  loggerEventKindEnum: {
    event: 'event',
  },
  loggerEventTypeEnum: {
    info: 'info',
    error: 'error',
  },
  loggerEventOutcomeEnum: {
    success: 'success',
    failure: 'failure',
  },
  Guid: {
    new: jest.fn(() => 'mock-guid'),
  },
}));

describe('LoggerService', () => {
  let service: LoggerService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LoggerService],
    });
    service = TestBed.inject(LoggerService);
  });

  it('should log an info message correctly', () => {
    const identifier = 'ComponentName';
    const methodName = 'MethodName';
    const msg = 'This is an info message';
    const info = { key: 'value' };

    service.logInfo(identifier, methodName, msg, info);

    const expectedMessage = `Report Unusual Activity - ${identifier} - ${methodName} - Info - ${msg}`;
    const expectedContextItems = {
      developerMessage: info,
      applicationName: 'ReportUnusualActivityWeb',
    };

    expect(logger.info).toHaveBeenCalledWith(
      expectedMessage,
      expectedContextItems,
      'mock-guid',
      loggerEventKindEnum.event,
      loggerEventTypeEnum.info,
      loggerEventOutcomeEnum.success,
    );
  });

  it('should log an info message without additional info', () => {
    const identifier = 'ComponentName';
    const methodName = 'MethodName';
    const msg = 'This is an info message';

    service.logInfo(identifier, methodName, msg);

    const expectedMessage = `Report Unusual Activity - ${identifier} - ${methodName} - Info - ${msg}`;
    const expectedContextItems = {
      developerMessage: undefined,
      applicationName: 'ReportUnusualActivityWeb',
    };

    expect(logger.info).toHaveBeenCalledWith(
      expectedMessage,
      expectedContextItems,
      'mock-guid',
      loggerEventKindEnum.event,
      loggerEventTypeEnum.info,
      loggerEventOutcomeEnum.success,
    );
  });

  it('should log an error message correctly', () => {
    const identifier = 'ComponentName';
    const methodName = 'MethodName';
    const msg = 'This is an error message';
    const err = new Error('Mock error');

    service.logError(identifier, methodName, msg, err);

    const expectedMessage = `Report Unusual Activity - ${identifier} - ${methodName} - Error - ${msg}`;
    const expectedContextItems = {
      developerMessage: err,
      applicationName: 'ReportUnusualActivityWeb',
    };

    expect(logger.error).toHaveBeenCalledWith(
      expectedMessage,
      expectedContextItems,
      'mock-guid',
      loggerEventKindEnum.event,
      loggerEventTypeEnum.error,
      loggerEventOutcomeEnum.failure,
    );
  });

  it('should log an error message without additional error details', () => {
    const identifier = 'ComponentName';
    const methodName = 'MethodName';
    const msg = 'This is an error message';

    service.logError(identifier, methodName, msg);

    const expectedMessage = `Report Unusual Activity - ${identifier} - ${methodName} - Error - ${msg}`;
    const expectedContextItems = {
      developerMessage: undefined,
      applicationName: 'ReportUnusualActivityWeb',
    };

    expect(logger.error).toHaveBeenCalledWith(
      expectedMessage,
      expectedContextItems,
      'mock-guid',
      loggerEventKindEnum.event,
      loggerEventTypeEnum.error,
      loggerEventOutcomeEnum.failure,
    );
  });
});
