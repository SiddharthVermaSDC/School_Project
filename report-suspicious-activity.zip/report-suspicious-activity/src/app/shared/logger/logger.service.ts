import { Injectable } from '@angular/core';
import {
    Guid,
    logger,
    loggerEventKindEnum,
    loggerEventOutcomeEnum,
    loggerEventTypeEnum } from '@lpl/core';

    const applicationName = 'ReportUnusualActivityWeb';
@Injectable({
    providedIn: 'root'
})

export class LoggerService {

    logInfo(identifier: string, methodName: string, msg: string, info: any = undefined) {
        const message = `Report Unusual Activity - ${identifier} - ${methodName} - Info - ${msg}`;

        const contextItems = {
            developerMessage: info,
            applicationName
          };

        logger.info(
            message,
            contextItems,
            Guid.new(),
            loggerEventKindEnum.event,
            loggerEventTypeEnum.info,
            loggerEventOutcomeEnum.success,
            );
    }

    logError(identifier: string, methodName: string, msg: string, err: any = undefined) {
        const message = `Report Unusual Activity - ${identifier} - ${methodName} - Error - ${msg}`;

        const contextItems = {
            developerMessage: err,
            applicationName
          };

        logger.error(
            message,
            contextItems,
            Guid.new(),
            loggerEventKindEnum.event,
            loggerEventTypeEnum.error,
            loggerEventOutcomeEnum.failure);
    }
}
