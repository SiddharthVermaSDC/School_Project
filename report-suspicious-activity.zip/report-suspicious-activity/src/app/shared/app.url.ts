export const environment={
   "ReferralAPI" : "https://webapidvi.dev.lpl.com/src-aml-rsa-api/",
}  
