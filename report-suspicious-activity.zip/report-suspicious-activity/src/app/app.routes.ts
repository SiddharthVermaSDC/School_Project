import { Route, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { ReferralComponent } from './feature/components/referral/referral.component';

export const appRoutes: Route[] = [
    { path: 'report-suspicious-activity/:account_no', component: ReferralComponent },
    { path: 'referral/:account_no', component: ReferralComponent },
    { path: 'referral', component: ReferralComponent }
];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }