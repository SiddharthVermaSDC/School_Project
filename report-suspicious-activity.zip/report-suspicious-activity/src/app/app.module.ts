import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { Rest } from '@lpl/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { APP_BASE_HREF } from '@angular/common';
import { appRoutes } from './app.routes';
import { ReferralComponent } from './feature/components/referral/referral.component';
import { ReferralApiService } from './core/services/referralApiService.service';
import { AppComponent } from './app.component';
import { LoggerService } from './shared/logger/logger.service';

@NgModule({
  declarations: [AppComponent,ReferralComponent],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes, { initialNavigation: 'enabledBlocking' }),
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [
    LoggerService,
    { provide: ReferralApiService},
    {
      provide: APP_BASE_HREF,
      useFactory: () => {
        const [, root] = window.location.pathname.split('/');
        return `//${window.location.host}/${root}/`;
      },
    }
  ],
  bootstrap: [AppComponent],
})
export class AppModule {
  constructor() {
    Rest.applicationName('reportSuspiciousActivityWeb');
  }
}

