import { Injectable } from '@angular/core';
import { Rest, RestResponse } from '@lpl/core'; 
import { CwEnvironmentConfig } from '@lpl/cw';
import { AccountDetailsResponse } from '../models/AccountDetailsResponse';
import { ITransactionApiResponse } from '../models/ITransactionApiResponse';
import { ICaseDetailsModelRequest } from '../models/ICaseDetailsModelRequest';
import { IReporerDetails } from '../models/IReporterDetails';
import { SubmittedCaseResponse } from '../models/SubmittedCaseResponse';
import { LoggerService } from '../../shared/logger/logger.service';

@Injectable({
  providedIn: 'root'
})
export class ReferralApiService extends CwEnvironmentConfig {

  constructor( private loggerService: LoggerService) {
    super();
  }

 public static get _baseApiUrl(): string {
  return ReferralApiService.getPropertyValue('webApiDomain');
}

  getAccountDetails(accountNumber: string): Promise<AccountDetailsResponse> {
    const url = `${ReferralApiService._baseApiUrl}/src-aml-rsa-api/account-details/${accountNumber}`;
    return Rest.get(url).then(response => {
      if (response) {
        return this.transformRestResponse(response);
      }
      this.loggerService.logError('ReferralApiService', 'getAccountDetails', 'Invalid response structure:', response);
      
      throw new Error('Something went wrong while fetching account details');
    }).catch(error => {

      this.loggerService.logError('ReferralApiService', 'getAccountDetails', 'Error fetching account details:', error);
      throw new Error('Failed to fetch account details');
    });
  }

  getReporterDetails(): Promise<IReporerDetails> {
    const url = `${ReferralApiService._baseApiUrl}/src-aml-rsa-api/reporter-details`;
    return Rest.get(url).then(response => 
      this.transformRestResponseForReporter(response));
  }
  getTransactionType(): Promise<ITransactionApiResponse> {
    const url = `${ReferralApiService._baseApiUrl}/src-aml-rsa-api/transaction-types`;
    return Rest.get(url).then(response=>this.transformRestResponse_TransactionType(response));
  }
  submitReferralForm(data: ICaseDetailsModelRequest): Promise<SubmittedCaseResponse> {
    const url = `${ReferralApiService._baseApiUrl}/src-aml-rsa-api/case-details`;
      return Rest.post(url,data).then(response=>this.transformRestResponse_CaseDetails(response));
  }

  public transformRestResponse(response: RestResponse): AccountDetailsResponse {
    return {
      master_repid:response.data.data.master_repid,
      status:response.data.status,
      clients_details_data: response.data.data.clients_details_data,
    } as AccountDetailsResponse;
  }
  private transformRestResponseForReporter(response: RestResponse): IReporerDetails {
    return {
      reporter_first_name:response.data.reporter_details.reporter_first_name,
      reporter_last_name:response.data.reporter_details.reporter_last_name,
      reporter_email:response.data.reporter_details.reporter_email_address,
    } as IReporerDetails;
  }

  private transformRestResponse_TransactionType(response: RestResponse): ITransactionApiResponse {
    return {
      transactionType: response.data.data,
    } as ITransactionApiResponse;
  }
  private transformRestResponse_CaseDetails(response: RestResponse): SubmittedCaseResponse {
    
    if (!response || !response.data || !response.data.data) {
      this.loggerService.logError('ReferralApiService', 'transformRestResponse_CaseDetails', 'Invalid response structure', response);
      return {
        status: '',
        reference_number: ''
      } as SubmittedCaseResponse; 
    }

    return {
      status: response.data.status,
      reference_number: response.data.data.reference_number
    } as SubmittedCaseResponse;
  }

}
