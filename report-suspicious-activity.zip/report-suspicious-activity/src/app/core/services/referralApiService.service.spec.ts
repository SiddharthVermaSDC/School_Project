/* eslint-disable import/first */
jest.mock('@lpl/cw', () => ({
  CwEnvironmentConfig: class {
    static getPropertyValue(key: string): string {
      return 'https://webapidvi.dev.lpl.com';
    }
  },
}));

import { TestBed } from '@angular/core/testing';
import { Rest } from '@lpl/core';
import { ReferralApiService } from './referralApiService.service';
import { AccountDetailsResponse } from '../models/AccountDetailsResponse';
import { ITransactionApiResponse } from '../models/ITransactionApiResponse';
import { ICaseDetailsModelRequest } from '../models/ICaseDetailsModelRequest';
import { IReporerDetails } from '../models/IReporterDetails';
import { LoggerService } from '../../shared/logger/logger.service';


// Mock Rest service
jest.mock('@lpl/core', () => ({
  Rest: {
    get: jest.fn(),
    post: jest.fn(),
  },
}));

describe('ReferralApiService', () => {
  let service: ReferralApiService;
  let mockRestGet: jest.Mock;
  let mockRestPost: jest.Mock;
  let mockLoggerService:any;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ReferralApiService, { provide: LoggerService, useValue: mockLoggerService },],
      
    });
    service = TestBed.inject(ReferralApiService);
    mockLoggerService = TestBed.inject(LoggerService);
    mockRestGet = Rest.get as jest.Mock;
    mockRestPost = Rest.post as jest.Mock;
    mockLoggerService = {
      logInfo: jest.fn(),
      logError: jest.fn(),
    };
  });
  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('getAccountDetails', () => {
    it('should call Rest.get with the correct URL and return transformed account details', async () => {
      const accountNumber = '65497603';
      const mockResponse = {
        data: {
          data: {
            account_no: '65497603',
            master_repid: 'E0PF',
            clients_details_data: [
              { client_name: 'TAYLOR EILEEN Z', client_ssn: '265913394', cust_acct_role_id: 'S' },
              { client_name: 'TAYLOR GLENN MARSHALL', client_ssn: '592169205', cust_acct_role_id: 'P' },
            ],
          },
        },
      };
      mockRestGet.mockResolvedValue(mockResponse);
      const result = await service.getAccountDetails(accountNumber);
      expect(mockRestGet).toHaveBeenCalledWith('https://webapidvi.dev.lpl.com/src-aml-rsa-api/account-details/65497603');
      expect(result).toEqual({
        master_repid: 'E0PF',
        clients_details_data: [
          { client_name: 'TAYLOR EILEEN Z', client_ssn: '265913394', cust_acct_role_id: 'S' },
          { client_name: 'TAYLOR GLENN MARSHALL', client_ssn: '592169205', cust_acct_role_id: 'P' },
        ],
      } as AccountDetailsResponse);
    });
    it('should throw an error when response is invalid', async () => {
      const accountNumber = '12345678';
      const invalidResponse = null; // Simulate an invalid response

      // Mock Rest.get to return an invalid response
      mockRestGet.mockResolvedValue(invalidResponse);

      await expect(service.getAccountDetails(accountNumber)).rejects.toThrow(
        'Failed to fetch account details'
      );

      expect(mockRestGet).toHaveBeenCalledWith(
        `${ReferralApiService._baseApiUrl}/src-aml-rsa-api/account-details/${accountNumber}`
      );
    });

    it('should throw an error when Rest.get fails', async () => {
      const accountNumber = '12345678';
      const error = new Error('Network error');

      // Mock Rest.get to reject with an error
      mockRestGet.mockRejectedValue(error);

      await expect(service.getAccountDetails(accountNumber)).rejects.toThrow(
        'Failed to fetch account details'
      );

      expect(mockRestGet).toHaveBeenCalledWith(
        `${ReferralApiService._baseApiUrl}/src-aml-rsa-api/account-details/${accountNumber}`
      );
    });
  });

  describe('getReporterDetails', () => {
    it('should call Rest.get with the correct URL and return reporter details', async () => {
      const mockResponse = {
        data: {
          reporter_details: {
            reporter_first_name: 'John',
            reporter_last_name: 'Doe',
            reporter_email_address: 'john.doe@lplfinancial.com',
          },
        },
      };
      mockRestGet.mockResolvedValue(mockResponse);
      const result = await service.getReporterDetails();
      expect(mockRestGet).toHaveBeenCalledWith('https://webapidvi.dev.lpl.com/src-aml-rsa-api/reporter-details');
      expect(result).toEqual({
        reporter_first_name: 'John',
        reporter_last_name: 'Doe',
        reporter_email: 'john.doe@lplfinancial.com',
      } as IReporerDetails);
    });
  });

  describe('getTransactionType', () => {
    it('should call Rest.get with the correct URL and return transaction types', async () => {
      const mockResponse = {
        data: {
          data: {
            transaction_types_info: {
              'Electronic Transfer': [
                'ACH Transaction',
                'Wire Transaction',
                'Debit Card Fraud',
                'ACH - UMB Transaction',
                'ACAT',
              ],
              'Check Fraud': ['LPL Issued Check', 'UMB Checkwriting'],
              'Identity Theft': [
                'Mail Theft',
                'Email Account Compromise',
                'Computer Intrusion',
                'Advisor or Client Impersonation',
              ],
              'Other Suspicious Activity': [
                'Money Laundering',
                'Forgery',
                'Insider Trading',
                'Suspicious money movement',
                'Source of Funds concerns',
                'Elder Financial Exploitation',
                'Other',
              ],
            },
          },
        },
      };
      mockRestGet.mockResolvedValue(mockResponse);
      const result = await service.getTransactionType();
      expect(mockRestGet).toHaveBeenCalledWith('https://webapidvi.dev.lpl.com/src-aml-rsa-api/transaction-types');
      expect(result).toEqual({
        transactionType: {
          transaction_types_info: mockResponse.data.data.transaction_types_info,
        },
      } as ITransactionApiResponse);
    });
  });

  describe('submitReferralForm', () => {
    it('should call Rest.post with the correct URL and return case details status', async () => {
      const formData: ICaseDetailsModelRequest = {
        account_no: '123456789',
        client_name: 'John Doe',
        client_ssn: '123-45-6789',
        master_rep_id: 'REP001',
        reporter_first_name: 'Jane',
        reporter_last_name: 'Smith',
        reporter_phone_no: '555-123-4567',
        reporter_email: 'jane.smith@example.com',
        transaction_type: 'Deposit',
        transaction_sub_type: 'Cash',
        trades_placed_flag: 'Y',
        transaction_details: 'Deposit of $10,000',
        additional_transaction_details: 'No additional details',
        other_suspicious_activity_details: 'None',
        senior_investor_involved_flag: 'N',
      };

      const mockResponse = {
        data: {
          status: 'success',
          data: {
            reference_number: 126,
          },
        },
      };

      mockRestPost.mockResolvedValue(mockResponse);

      const result = await service.submitReferralForm(formData);

      expect(mockRestPost).toHaveBeenCalledWith('https://webapidvi.dev.lpl.com/src-aml-rsa-api/case-details', formData);
      expect(result).toEqual({ status: 'success', reference_number: 126 });
    });

    it('should handle invalid response structure (missing data or data.data)', async () => {
      const formData: ICaseDetailsModelRequest = {
        account_no: '123456789',
        client_name: 'John Doe',
        client_ssn: '123-45-6789',
        master_rep_id: 'REP001',
        reporter_first_name: 'Jane',
        reporter_last_name: 'Smith',
        reporter_phone_no: '555-123-4567',
        reporter_email: 'jane.smith@example.com',
        transaction_type: 'Deposit',
        transaction_sub_type: 'Cash',
        trades_placed_flag: 'Y',
        transaction_details: 'Deposit of $10,000',
        additional_transaction_details: 'No additional details',
        other_suspicious_activity_details: 'None',
        senior_investor_involved_flag: 'N',
      };

      const mockInvalidResponse = { data: {} };
      mockRestPost.mockResolvedValue(mockInvalidResponse);

      const result = await service.submitReferralForm(formData);

      expect(mockRestPost).toHaveBeenCalledWith('https://webapidvi.dev.lpl.com/src-aml-rsa-api/case-details', formData);
      expect(result).toEqual({ status: '', reference_number: '' });
    });

    it('should handle empty response (undefined or null)', async () => {
      const formData: ICaseDetailsModelRequest = {
        account_no: '123456789',
        client_name: 'John Doe',
        client_ssn: '123-45-6789',
        master_rep_id: 'REP001',
        reporter_first_name: 'Jane',
        reporter_last_name: 'Smith',
        reporter_phone_no: '555-123-4567',
        reporter_email: 'jane.smith@example.com',
        transaction_type: 'Deposit',
        transaction_sub_type: 'Cash',
        trades_placed_flag: 'Y',
        transaction_details: 'Deposit of $10,000',
        additional_transaction_details: 'No additional details',
        other_suspicious_activity_details: 'None',
        senior_investor_involved_flag: 'N',
      };

      mockRestPost.mockResolvedValue(null);

      const result = await service.submitReferralForm(formData);

      expect(mockRestPost).toHaveBeenCalledWith('https://webapidvi.dev.lpl.com/src-aml-rsa-api/case-details', formData);
      expect(result).toEqual({ status: '', reference_number: '' });
    });

    it('should handle error response gracefully', async () => {
      const formData: ICaseDetailsModelRequest = {
        account_no: '123456789',
        client_name: 'John Doe',
        client_ssn: '123-45-6789',
        master_rep_id: 'REP001',
        reporter_first_name: 'Jane',
        reporter_last_name: 'Smith',
        reporter_phone_no: '555-123-4567',
        reporter_email: 'jane.smith@example.com',
        transaction_type: 'Deposit',
        transaction_sub_type: 'Cash',
        trades_placed_flag: 'Y',
        transaction_details: 'Deposit of $10,000',
        additional_transaction_details: 'No additional details',
        other_suspicious_activity_details: 'None',
        senior_investor_involved_flag: 'N',
      };

      mockRestPost.mockRejectedValue(new Error('Network error'));

      await expect(service.submitReferralForm(formData)).rejects.toThrow('Network error');
    });
  });

  it('should handle invalid response structure (missing data or data.data)', async () => {
    const formData: ICaseDetailsModelRequest = {
      account_no: '123456789',
      client_name: 'John Doe',
      client_ssn: '123-45-6789',
      master_rep_id: 'REP001',
      reporter_first_name: 'Jane',
      reporter_last_name: 'Smith',
      reporter_phone_no: '555-123-4567',
      reporter_email: 'jane.smith@example.com',
      transaction_type: 'Deposit',
      transaction_sub_type: 'Cash',
      trades_placed_flag: 'Y',
      transaction_details: 'Deposit of $10,000',
      additional_transaction_details: 'No additional details',
      other_suspicious_activity_details: 'None',
      senior_investor_involved_flag: 'N',
    };
  
    const mockInvalidResponse = { data: {} };
    mockRestPost.mockResolvedValue(mockInvalidResponse);
    const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
  
    const result = await service.submitReferralForm(formData);
  
    expect(mockRestPost).toHaveBeenCalledWith(
      'https://webapidvi.dev.lpl.com/src-aml-rsa-api/case-details',
      formData
    );
    expect(result).toEqual({ status: '', reference_number: '' }); // Ensure default values are returned
    consoleErrorSpy.mockRestore();
  });
  
  it('should handle empty response (undefined or null)', async () => {
    const formData: ICaseDetailsModelRequest = {
      account_no: '123456789',
      client_name: 'John Doe',
      client_ssn: '123-45-6789',
      master_rep_id: 'REP001',
      reporter_first_name: 'Jane',
      reporter_last_name: 'Smith',
      reporter_phone_no: '555-123-4567',
      reporter_email: 'jane.smith@example.com',
      transaction_type: 'Deposit',
      transaction_sub_type: 'Cash',
      trades_placed_flag: 'Y',
      transaction_details: 'Deposit of $10,000',
      additional_transaction_details: 'No additional details',
      other_suspicious_activity_details: 'None',
      senior_investor_involved_flag: 'N',
    };
    mockRestPost.mockResolvedValue(null);
    const result = await service.submitReferralForm(formData);
    expect(mockRestPost).toHaveBeenCalledWith('https://webapidvi.dev.lpl.com/src-aml-rsa-api/case-details', formData);
    expect(result).toEqual({ status: '', reference_number: '' }); // Ensure default values are returned
  });

  it('should handle error response gracefully', async () => {
    const formData: ICaseDetailsModelRequest = {
      account_no: '123456789',
      client_name: 'John Doe',
      client_ssn: '123-45-6789',
      master_rep_id: 'REP001',
      reporter_first_name: 'Jane',
      reporter_last_name: 'Smith',
      reporter_phone_no: '555-123-4567',
      reporter_email: 'jane.smith@example.com',
      transaction_type: 'Deposit',
      transaction_sub_type: 'Cash',
      trades_placed_flag: 'Y',
      transaction_details: 'Deposit of $10,000',
      additional_transaction_details: 'No additional details',
      other_suspicious_activity_details: 'None',
      senior_investor_involved_flag: 'N',
    };

    mockRestPost.mockRejectedValue(new Error('Network error'));
    try {
      await service.submitReferralForm(formData);
    } catch (error: unknown) {
      expect(error).toBeInstanceOf(Error);
    }
  });

});
