import { AbstractControl, ValidationErrors } from '@angular/forms';

export class ReferralCustomValidators {
  
  static lplAccountValidator(control: AbstractControl): ValidationErrors | null {
    const accountPattern = /^[a-zA-Z0-9]{8,10}$/; // 8 to 10 alphanumeric characters
    return accountPattern.test(control.value) ? null : { invalidAccount: true };
  }

  static phoneValidator(control: AbstractControl): ValidationErrors | null {
    const phonePattern = /^(?:\d{3}-\d{3}-\d{4}|\d{10})$/; // Match either XXX-XXX-XXXX or XXXXXXXXXX
    return phonePattern.test(control.value) ? null : { invalidPhone: true };
  }
  static emailValidator(control: AbstractControl): ValidationErrors | null {
    const emailPattern = /^[a-zA-Z0-9._%+-]+@lpl(financial|)\.com$/;
    return emailPattern.test(control.value) ? null : { invalidEmail: true };
}

  static otherDetailsValidator(control: AbstractControl): ValidationErrors | null {
    // Check if the field is empty first (optional check), then validate regex
    if (!control.value) {
      return null;  // If it's empty, consider it valid
    }
  
    const otherDetailsPattern = /^[a-zA-Z0-9\s]{1,50}$/; // 1 to 50 alphanumeric characters
    return otherDetailsPattern.test(control.value) ? null : { invalidOtherDetails: true };
  }
  
  static additionalDetailsValidator(control: AbstractControl): ValidationErrors | null {
    // Check if the field is empty first (optional check), then validate regex
    if (!control.value) {
      return null;  // If it's empty, consider it valid
    }
  
    const additionalDetailsPattern = /^[a-zA-Z0-9\s]{1,2000}$/; // 1 to 2000 alphanumeric characters, including spaces
    return additionalDetailsPattern.test(control.value) ? null : { invalidAdditionalDetails: true };
  }
}
