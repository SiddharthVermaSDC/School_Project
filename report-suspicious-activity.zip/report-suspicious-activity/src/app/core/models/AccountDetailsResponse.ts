import { ClientDetailsData } from "./ClientDetialsData";

export class AccountDetailsResponse {
    account_no?: string;
    master_repid?: string;
    status?:string;
    clients_details_data: ClientDetailsData[];

    constructor() {
        this.clients_details_data = [];
    }
}