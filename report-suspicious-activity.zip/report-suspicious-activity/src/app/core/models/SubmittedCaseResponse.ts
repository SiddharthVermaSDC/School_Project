export class SubmittedCaseResponse {
    status?: string;
    reference_number?: string;
}