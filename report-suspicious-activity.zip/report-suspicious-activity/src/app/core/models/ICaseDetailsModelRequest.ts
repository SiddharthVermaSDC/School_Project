export interface ICaseDetailsModelRequest {
    account_no?: string;
    client_name?: string;
    client_ssn?: string;
    master_rep_id?: string;
    reporter_first_name?: string;
    reporter_last_name?: string;
    reporter_phone_no?: string;
    reporter_email?: string;
    transaction_type?: string;
    transaction_sub_type?: string;
    trades_placed_flag?: string;
    transaction_details?: string;
    additional_transaction_details?: string;
    other_suspicious_activity_details?:string;
    senior_investor_involved_flag?:string; 
}