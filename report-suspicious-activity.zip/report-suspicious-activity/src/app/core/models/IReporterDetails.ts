export interface IReporerDetails {
    reporter_full_name?: string;
    reporter_first_name?: string;
    reporter_last_name?: string;
    reporter_email?: string;
}