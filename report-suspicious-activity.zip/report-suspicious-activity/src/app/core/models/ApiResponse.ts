export class ApiResponse {
    static readonly SuccessStatus: string = "success";
    static readonly FailureStatus: string = "failure";

    status?: string;
    statusMessage?: string;
    data?: any;
    errors?: Error[];
}