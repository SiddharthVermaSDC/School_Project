import { ITransactionTypesInfo } from "./ITransactionTypesInfo";

export interface ITransactionApiResponse  {
  transactionType: {
    transaction_types_info: ITransactionTypesInfo;
  };
}
