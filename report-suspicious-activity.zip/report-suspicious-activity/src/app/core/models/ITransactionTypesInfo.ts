export interface ITransactionTypesInfo {
  [key: string]: string[];
  }