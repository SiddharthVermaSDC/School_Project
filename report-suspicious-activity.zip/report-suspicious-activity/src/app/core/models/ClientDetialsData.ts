export class ClientDetailsData {
    client_name?: string;
    client_ssn?: string;
    cust_acct_role_id?: string;
}