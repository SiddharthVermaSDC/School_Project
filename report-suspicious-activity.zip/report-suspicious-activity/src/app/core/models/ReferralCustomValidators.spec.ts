import { AbstractControl, ValidationErrors } from '@angular/forms';
import { ReferralCustomValidators } from './ReferralCustomValidators';

class MockAbstractControl extends AbstractControl {
  // Constructor to initialize the value for the control
  constructor(public override value: any) {
    super(null, null);  // Pass null to super constructor as AbstractControl expects these arguments
  }

  // Simulate the patchValue method
  override patchValue(value: any, options?: object): void {
    this.value = value;
  }
  override reset(value?: any, options?: object): void {
    this.value = value ?? null;
  }
  setValue(value: string): void {
    this.value = value;
  }
  override get valid(): boolean {
    return true; // You can customize this if needed
  }
  // Validation logic or error handling can be added here if necessary
  override setErrors(errors: ValidationErrors | null): void {
    // You can implement custom error setting if needed for your mock control
    super.setErrors(errors);
  }
}


describe('ReferralCustomValidators', () => {
  describe('lplAccountValidator', () => {
    let control: AbstractControl;

    it('should return null for a valid account', () => {
      control = new MockAbstractControl('Valid123');
      const result = ReferralCustomValidators.lplAccountValidator(control);
      expect(result).toBeNull();
    });

    it('should return error object for an invalid account (more than 10 characters)', () => {
      control = new MockAbstractControl('InvalidAccount123');
      const result = ReferralCustomValidators.lplAccountValidator(control);
      expect(result).toEqual({ invalidAccount: true });
    });

    it('should return error object for an invalid account (non-alphanumeric)', () => {
      control = new MockAbstractControl('Invalid@123');
      const result = ReferralCustomValidators.lplAccountValidator(control);
      expect(result).toEqual({ invalidAccount: true });
    });

    it('should return error object for an empty account', () => {
      control = new MockAbstractControl('');
      const result = ReferralCustomValidators.lplAccountValidator(control);
      expect(result).toEqual({ invalidAccount: true });
    });
  });

  describe('phoneValidator', () => {
    let control: AbstractControl;

    it('should return null for a valid phone number', () => {
      control = new MockAbstractControl('123-456-7890');
      const result = ReferralCustomValidators.phoneValidator(control);
      expect(result).toBeNull();
    });

    it('should return error object for an invalid phone number (too few digits)', () => {
      control = new MockAbstractControl('123-45-789');
      const result = ReferralCustomValidators.phoneValidator(control);
      expect(result).toEqual({ invalidPhone: true });
    });

    it('should return error object for an invalid phone number (wrong format)', () => {
      control = new MockAbstractControl('123/456/7890');
      const result = ReferralCustomValidators.phoneValidator(control);
      expect(result).toEqual({ invalidPhone: true });
    });

    it('should return error object for an empty phone number', () => {
      control = new MockAbstractControl('');
      const result = ReferralCustomValidators.phoneValidator(control);
      expect(result).toEqual({ invalidPhone: true });
    });
  });

  describe('emailValidator', () => {
    let control: AbstractControl;
  
    it('should return null for a valid email address with @lplfinancial.com', () => {
      control = new MockAbstractControl('valid@lplfinancial.com');
      const result = ReferralCustomValidators.emailValidator(control);
      expect(result).toBeNull();  // Expect null for valid email
    });
  
    it('should return null for a valid email address with @lpl.com', () => {
      control = new MockAbstractControl('valid@lpl.com');
      const result = ReferralCustomValidators.emailValidator(control);
      expect(result).toBeNull();  // Expect null for valid email
    });
  
    it('should return error object for an invalid email address with a wrong domain', () => {
      control = new MockAbstractControl('invalid@google.com');
      const result = ReferralCustomValidators.emailValidator(control);
      expect(result).toEqual({ invalidEmail: true });  // Expect error for invalid domain
    });
  
    it('should return error object for an empty email address', () => {
      control = new MockAbstractControl('');
      const result = ReferralCustomValidators.emailValidator(control);
      expect(result).toEqual({ invalidEmail: true });  // Expect error for empty email
    });
  
    it('should return error object for an email address with a missing domain part', () => {
      control = new MockAbstractControl('invalid@.com');
      const result = ReferralCustomValidators.emailValidator(control);
      expect(result).toEqual({ invalidEmail: true });  // Expect error for missing domain part
    });
  
    it('should return error object for an email address with an invalid domain (e.g., lpl.financial)', () => {
      control = new MockAbstractControl('invalid@lpl.financial');
      const result = ReferralCustomValidators.emailValidator(control);
      expect(result).toEqual({ invalidEmail: true });  // Expect error for invalid domain part
    });
  
    it('should return error object for an email address with extra characters (e.g., test@@lplfinancial.com)', () => {
      control = new MockAbstractControl('test@@lplfinancial.com');
      const result = ReferralCustomValidators.emailValidator(control);
      expect(result).toEqual({ invalidEmail: true });  // Expect error for extra @ symbol
    });
  });
  
  
  describe('otherDetailsValidator', () => {
    let control: AbstractControl;

    it('should return null for valid other details', () => {
      control = new MockAbstractControl('Valid details 123');
      const result = ReferralCustomValidators.otherDetailsValidator(control);
      expect(result).toBeNull();
    });

    it('should return error object for invalid other details (too long)', () => {
      control = new MockAbstractControl('This is a very long string that should be invalid because it exceeds fifty characters for the test.');
      const result = ReferralCustomValidators.otherDetailsValidator(control);
      expect(result).toEqual({ invalidOtherDetails: true });
    });

    it('should return error object for invalid other details (non-alphanumeric characters)', () => {
      control = new MockAbstractControl('Invalid!@#details');
      const result = ReferralCustomValidators.otherDetailsValidator(control);
      expect(result).toEqual({ invalidOtherDetails: true });
    });

    it('should return error object for an empty value', () => {
      control = new MockAbstractControl('');
      const result = ReferralCustomValidators.otherDetailsValidator(control);
      expect(result).toBeNull();
    });
  });

  describe('additionalDetailsValidator', () => {
    let control: AbstractControl;

    it('should return null for valid additional details', () => {
      control = new MockAbstractControl('Valid additional details up to 2000 characters.');
      const result = ReferralCustomValidators.additionalDetailsValidator(control);
      expect(result).toEqual({ invalidAdditionalDetails: true });
    });

    it('should return error object for invalid additional details (too long)', () => {
      const longValue = 'A'.repeat(2001);  // String length 2001, exceeds limit
      control = new MockAbstractControl(longValue);
      const result = ReferralCustomValidators.additionalDetailsValidator(control);
      expect(result).toEqual({ invalidAdditionalDetails: true });
    });

    it('should return error object for invalid additional details (non-alphanumeric characters)', () => {
      control = new MockAbstractControl('Invalid additional details @!#');
      const result = ReferralCustomValidators.additionalDetailsValidator(control);
      expect(result).toEqual({ invalidAdditionalDetails: true });
    });

    it('should return error object for an empty value', () => {
      control = new MockAbstractControl('');
      const result = ReferralCustomValidators.additionalDetailsValidator(control);
      expect(result).toBeNull();
    });
  });

});
