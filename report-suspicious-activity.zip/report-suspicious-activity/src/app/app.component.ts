import { Component, OnInit } from '@angular/core';
import { rest, logger, loggerApplicationCategoryEnum, loggerApplicationGroupEnum } from '@lpl/core';
import { LwkThemes, LwkThemesEnum } from '@lpl/themes';

@Component({
  selector: 'src-aml-reportsuspiciousactivity-web-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  title = 'report-unusual-activity';

  
  ngOnInit(): void {
    if (logger) {
      logger.init("ReportUnusualActivityWeb", loggerApplicationCategoryEnum.homeOffice, loggerApplicationGroupEnum.clr);
    } 
    rest.config(true, true);
    LwkThemes.setTheme(LwkThemesEnum.cwDefault);
  }
}
