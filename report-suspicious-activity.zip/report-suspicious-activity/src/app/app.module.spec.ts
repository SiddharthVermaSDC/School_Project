import { TestBed } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Rest } from '@lpl/core';
import { AppModule } from './app.module';
import { AppComponent } from './app.component';
import { ReferralApiService } from './core/services/referralApiService.service';
import { ReferralComponent } from './feature/components/referral/referral.component';


// Mock Rest service to check if applicationName method is called
jest.mock('@lpl/core', () => ({
  Rest: {
    applicationName: jest.fn(),
  }
}));
jest.mock('@lpl/cw', () => ({
  CwEnvironmentConfig: class {
    static getPropertyValue(key: string): string {
      return '';
    }
  }
}));
describe('AppModule', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        AppModule,
        BrowserModule,
        RouterModule.forRoot([]),
        HttpClientModule,
        FormsModule,
        ReactiveFormsModule,
      ],
      declarations: [AppComponent, ReferralComponent],
      providers: [ReferralApiService],
    }).compileComponents();
  });

  it('should create the AppModule', () => {
    const module = TestBed.inject(AppModule);
    expect(module).toBeTruthy();
  });

  it('should call Rest.applicationName with "reportSuspiciousActivityWeb"', () => {
    expect(Rest.applicationName).toHaveBeenCalledWith('reportSuspiciousActivityWeb');
  });

  it('should declare AppComponent and ReferralComponent', () => {
    const appFixture = TestBed.createComponent(AppComponent);
    expect(appFixture).toBeTruthy();

    const referralFixture = TestBed.createComponent(ReferralComponent);
    expect(referralFixture).toBeTruthy();
  });

  it('should import necessary modules', () => {
    const browserModule = TestBed.inject(BrowserModule);
    const routerModule = TestBed.inject(RouterModule);
    const httpClientModule = TestBed.inject(HttpClientModule);
    const formsModule = TestBed.inject(FormsModule);
    const reactiveFormsModule = TestBed.inject(ReactiveFormsModule);

    expect(browserModule).toBeTruthy();
    expect(routerModule).toBeTruthy();
    expect(httpClientModule).toBeTruthy();
    expect(formsModule).toBeTruthy();
    expect(reactiveFormsModule).toBeTruthy();
  });

  it('should provide ReferralApiService', () => {
    const service = TestBed.inject(ReferralApiService);
    expect(service).toBeTruthy();
  });
});
