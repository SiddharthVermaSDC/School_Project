import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, ValidationErrors, Validators } from '@angular/forms';
import { ActivatedRoute,Router } from '@angular/router';
import { ReferralApiService } from '../../../core/services/referralApiService.service';
import { AccountDetailsResponse } from '../../../core/models/AccountDetailsResponse';
import { ITransactionApiResponse } from '../../../core/models/ITransactionApiResponse';
import { IReporerDetails } from '../../../core/models/IReporterDetails';
import { ReferralCustomValidators } from '../../../core/models/ReferralCustomValidators';
import { LoggerService } from '../../../shared/logger/logger.service';

@Component({
  selector: 'src-aml-reportsuspiciousactivity-web-referral',
  templateUrl: './referral.component.html',
  styleUrls: ['./referral.component.scss'],
})
export class ReferralComponent implements OnInit {

  accountDetails: AccountDetailsResponse[] = [];
  clientNames:any[]=[];
  tempData:any[]=[];
  transactionTypes:string[] = [];
  transactionSubTypes:string[] = [];
  trades_placed_flag_Options = [
    { key: 'Y', value: 'Yes' },
    { key: 'N', value: 'No' }
  ];

  showSeniorInvestorInvolvedFlag = false;

  senior_investor_involved_flag_Options = [
    { key: 'Y', value: 'Yes' },
    { key: 'N', value: 'No' }
  ];

  selectedClientName: any = ''; 
  selectedTransactionType = ''; 
  selectedTransactionSubType = '';
  selectedOtherSuspiciousActivity = ''; 
  submitted = false;
  isVisible = true;
  showDialog = false;
  IsInvalidAccountNo=false;
  referralForm: any;
  showReferenceNumber = false;
  transactionSubTypeVisible = false;
  referenceNumber: any;
  // eslint-disable-next-line max-params
  constructor(
    public _formBuilder: FormBuilder, 
    private _referralApiService: ReferralApiService,
    private _route: ActivatedRoute,
    private router: Router,
    private loggerService: LoggerService
  ) {}

  ngOnInit(): void { 
    this.referralForm = this._formBuilder.group(
      {
        account_no: ['', [Validators.required, ReferralCustomValidators.lplAccountValidator]],
        master_rep_id: [{ value: '', disabled: true }],
        client_name: [''] ,
        client_ssn: [{ value: '', disabled: true }],
        reporter_first_name:[{value:'',disabled:true},[Validators.required]],
        reporter_last_name:[{value:'',disabled:true},[Validators.required]],
        reporter_email: [{value:'',disabled:true}, [Validators.required, ReferralCustomValidators.emailValidator]],
        reporter_phone_no: ['', [Validators.required,Validators.maxLength(12), ReferralCustomValidators.phoneValidator]],
        transaction_type:['', [Validators.required,this.invalidTransactionType] ],
        transaction_sub_type:['', [Validators.required, this.invalidTransactionSubType] ],
        trades_placed_flag: ['N'],
        senior_Investor_Involved: ['N'],
        other_suspicious_activity_details:['',ReferralCustomValidators.otherDetailsValidator],
        additional_transaction_details: ['', ReferralCustomValidators.additionalDetailsValidator],   
     },
    );  
    this.toggleClientNameValidation(!this.isVisible);
    this._route.queryParamMap.subscribe(params => {
      const accountNo = params.get('account_no');
      if (accountNo) {
        this.referralForm.get('account_no')?.setValue(accountNo); // Set the account number  
        this.referralForm.get('account_no')?.disable();
        this.getAccountDetailsByAccountNo();
        this.isVisible=true;
      } else {
        this.isVisible=false;
        this.referralForm.get('account_no')?.enable(); // Enable the field
      }
    });
    this.getReporterDetails();
    this.getTransactionType();

  }

  sanitizeAccountNo(event: any): void {
    const inputValue = event.target.value;
    const sanitizedValue = inputValue.replace(/[^a-zA-Z0-9]/g, '');  // Remove any non-alphanumeric character
    // eslint-disable-next-line no-param-reassign
    event.target.value = sanitizedValue;
    this.referralForm.controls['account_no'].setValue(sanitizedValue);
  }

  toggleClientNameValidation(isVisible: boolean): void {
    const clientNameControl = this.referralForm.get('client_name');
  
    if (isVisible) {
      clientNameControl?.setValidators([Validators.required]);
    } else {
      clientNameControl?.clearValidators();
    }
  
    clientNameControl?.updateValueAndValidity(); 
  }

  invalidTransactionType(control: AbstractControl): ValidationErrors | null {
    return control.value === '--Select Transaction Type--' ? { invalidSelect: true } : null;
  }
  invalidTransactionSubType(control: AbstractControl): ValidationErrors | null {
    return control.value === '--Select Transaction SubType--' ? { invalidSelect: true } : null;
  }

  get f(): { [key: string]: AbstractControl } {
    return this.referralForm.controls;
  }
  
  getReporterDetails() {
    this._referralApiService.getReporterDetails()
    .then((response: IReporerDetails) => {
       if (response) {
          this.referralForm.get('reporter_first_name')?.setValue(response.reporter_first_name);
          this.referralForm.get('reporter_last_name')?.setValue(response.reporter_last_name);
          this.referralForm.get('reporter_email')?.setValue(response.reporter_email);
        }
        else{
          this.loggerService.logInfo('ReferralComponent','getReporterDetails','Reporter Details not found');
        }
    })
    .catch((error: any) => {
        this.loggerService.logError('ReferralComponent', 'getReporterDetails', 'Error Occurred while fetching reporter details', error);
    });
  }

  getAccountDetailsByAccountNo() {
    this.resetAccountDetails();
    const accountNo = this.referralForm.get('account_no')?.value;

    if (!accountNo || accountNo.length < 8 || accountNo.length > 10) {
      this.IsInvalidAccountNo = true; 
    } else {
      this.IsInvalidAccountNo = false; 
      this._referralApiService.getAccountDetails(accountNo)
        .then((response: any) => {
          if (response.status === 'success') {
            this.handleAccountDetails(response);
          } else {
            this.handleFailedResponse();
          }
        })
        .catch((error: any) => {
          this.loggerService.logError('ReferralComponent', 'getAccountDetailsByAccountNo', 'Error occurred while fetching account details', error);
        });
    }
  }
  
  public handleAccountDetails(response: AccountDetailsResponse) {
    this.accountDetails = [response];
    this.tempData = this.accountDetails;
    this.setMasterRepId(response);
  
    if (response.clients_details_data) {
      this.handleClientDetails(response.clients_details_data);
    }
  }
  
  public setMasterRepId(account: AccountDetailsResponse) {
    const masterRepIdControl = this.referralForm.get('master_rep_id');
    if (masterRepIdControl) {
      masterRepIdControl.setValue(account.master_repid);
    } else {
      this.loggerService.logInfo('ReferralComponent','setMasterRepId','Master Rep ID control not found');
    }
  }
  
  public handleClientDetails(clientsDetails: any[]) {
    this.clientNames = clientsDetails.map(detail => detail.client_name);
    
    const primaryClient = clientsDetails.find(detail => detail.cust_acct_role_id === 'P');
    if (primaryClient) {
      this.referralForm.get('client_name')?.setValue(primaryClient.client_name);
      this.referralForm.get('client_ssn')?.setValue(primaryClient.client_ssn);
    }
  
    this.isVisible = this.clientNames.length >= 1;
  }
  
  public handleFailedResponse() {
    this.resetAccountDetails();
    this.isVisible = false;
    this.showDialog = true;
  }

  clientNameChange(event: Event): void {
    const target = event.target as HTMLSelectElement;
    const selectedClientName = target.value;
    const clientDetail = this.tempData[0].clients_details_data.find(
      (      detail: { client_name: string; }) => detail.client_name === selectedClientName
    );
    if (clientDetail) {
      this.referralForm.get('client_ssn')?.setValue(clientDetail.client_ssn);
    } else {
      this.referralForm.get('client_ssn')?.setValue('');
    }
  }

  formatPhoneNumber(event: any): void {
    const input = event.target;
    const rawValue = input.value.replace(/\D/g, ''); // Remove non-numeric characters

    if (rawValue.length <= 10) {
      input.value = this.applyPhoneNumberMask(rawValue);
    }
  }

  formatPhoneNumberOnBlur(): void {
    const phoneControl = this.f['reporter_phone_no'];
    if (phoneControl.value) {
      const formattedValue = this.applyPhoneNumberMask(
        phoneControl.value.replace(/\D/g, '')
      );
      phoneControl.setValue(formattedValue);
    }
  }
  applyPhoneNumberMask(value: string): string {
    // Match the number pattern and format it like 123-456-7890
    const phoneNumber = value.replace(/\D/g, ''); // Remove non-numeric characters
    const match = phoneNumber.match(/^(\d{1,3})(\d{1,3})?(\d{1,4})?/);
  
    if (match) {
      const part1 = match[1] ? match[1] : '';
      const part2 = match[2] ? match[2] : '';
      const part3 = match[3] ? match[3] : '';
  
      if (part2 && part3) {
        return `${part1}-${part2}-${part3}`;
      }
      if (part2) {
        return `${part1}-${part2}`;
      }
      return part1;
    }
    return value;
  }
  

  getTransactionType() {
    this._referralApiService.getTransactionType()
    .then((response: ITransactionApiResponse) => {
     
        this.transactionTypes = ['--Select Transaction Type--', ...Object.keys(response.transactionType.transaction_types_info)];
        // Set the default value for transaction type
        this.referralForm.get('transaction_type')?.setValue('--Select Transaction Type--');

        // Subscribe to value changes and set the default subtype
        this.referralForm.get('transaction_type')?.valueChanges.subscribe((selectedType: string) => {
          this.selectedTransactionType=selectedType;
          this.referralForm.get('trades_placed_flag')?.setValue('N');
          this.referralForm.get('senior_Investor_Involved')?.setValue('N');
          if(this.selectedTransactionType==='--Select Transaction Type--') {
           this.transactionSubTypes=[];
          }
          else{
            // Add the default option for subtypes
            this.transactionSubTypes = ['--Select Transaction SubType--', ...(response.transactionType.transaction_types_info[selectedType] || [])];
            // Set the default value for transaction sub type
            this.referralForm.get('transaction_sub_type')?.setValue('--Select Transaction SubType--'); // Reset subtype on type change
            this.referralForm.get('other_suspicious_activity_details')?.setValue('');
          }    
        });
        this.referralForm.get('transaction_sub_type')?.valueChanges.subscribe(() => {
          this.referralForm.get('other_suspicious_activity_details')?.setValue('');
        });
    })
    .catch((error: any) => {
        this.transactionTypes = ['--Select Transaction Type--'];
        this.referralForm.get('transaction_type')?.setValue('--Select Transaction Type--');
        this.referralForm.get('transaction_sub_type')?.setValue('--Select Transaction SubType--'); // Reset subtype in case of error
        this.referralForm.get('other_suspicious_activity_details')?.setValue('');
        this.loggerService.logError('ReferralComponent', 'getTransactionType', 'Error Occurred while fetching transaction types', error);
    });
  }

transactionTypeChange() {
  this.showSeniorInvestorInvolvedFlag = false;
  this.transactionSubTypeVisible = true;

  if(this.selectedTransactionType === 'Senior Client Guidance Request') {
    this.transactionSubTypeVisible = false;
    this.selectedTransactionSubType = 'N/A';
    this.referralForm.get('transaction_sub_type')?.setValue('N/A');
  }

  if(this.selectedTransactionType === 'Electronic Transfer' || 
    this.selectedTransactionType === 'Check Fraud' ) {
      this.showSeniorInvestorInvolvedFlag = true;
    }
  }

transactionSubTypeChange(event: Event) {
  const target = event.target as HTMLSelectElement;
  const selectedTransactionSubType = target.value;
  this.selectedTransactionSubType = selectedTransactionSubType;

  this.showSeniorInvestorInvolvedFlag = false;

  if(this.selectedTransactionType === 'Senior Client Guidance Request') {
    this.selectedTransactionSubType = 'N/A';
  }

  if(this.selectedTransactionType === 'Electronic Transfer' || 
     this.selectedTransactionType === 'Check Fraud' || 
     (this.selectedTransactionType === 'Identity Theft' && this.selectedTransactionSubType === 'Advisor or Client Impersonation') || 
     (this.selectedTransactionType === 'Other Suspicious Activity' && 
        ( this.selectedTransactionSubType === 'Elder Financial Exploitation' || this.selectedTransactionSubType === 'Other'))
    ) {
     this.showSeniorInvestorInvolvedFlag = true;
  }

  }

submitReferralForm(): void {
  // eslint-disable-next-line no-debugger
  debugger
  this.submitted = true;
  if (this.referralForm.valid) {
    this.referralForm.get('account_no')?.enable();
    this.referralForm.get('master_rep_id')?.enable();
    this.referralForm.get('client_ssn')?.enable();
    this.referralForm.get('reporter_first_name')?.enable();
    this.referralForm.get('reporter_last_name')?.enable();
    this.referralForm.get('reporter_email')?.enable();
    const referralData = this.referralForm.value;
    // eslint-disable-next-line no-debugger
    debugger;
    this._referralApiService.submitReferralForm(referralData).then((response: any) => {
      if (response.status === 'success') {
        this.referenceNumber = response.reference_number;
        this.showReferenceNumber = true;
        this.resetReferralForm();
      } else {
        this.resetReferralForm();
        this.loggerService.logInfo('ReferralComponent','submitReferralForm','Response statis is not success');
      }
    }).catch((error: any) => {
      this.loggerService.logError('ReferralComponent', 'submitReferralForm', 'Error Occurred while submitting referral form', error);
    });
  } else {
    this.referralForm.markAllAsTouched();
    const invalidControls = [];
    const {controls} = this.referralForm;
    for (const name in controls) {
      if (controls[name].invalid) {
        invalidControls.push(name);
      }
    }
    this.loggerService.logInfo('ReferralComponent','submitReferralForm','Invalid form controls',invalidControls);
  }
  }

onKeyDown(event: KeyboardEvent): void {
  if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault();
    this.btnReset();
  }
  }

btnReset(): void {
  this.router.navigate(['']); 
  this.resetAccountDetails();
  this.resetReferralForm();
  }

  resetAccountDetails(): void {
    this.accountDetails = [];
    this.clientNames=[];
    this.selectedClientName = '';
    this.referralForm.patchValue({
      clientName: this.selectedClientName,
      client_ssn: '',
      master_rep_id: ''
    });
    this.IsInvalidAccountNo=false
  }
  resetReferralForm(): void {
    this.referralForm.reset({
      account_no: '',
      master_rep_id: { value: '', disabled: true },
      client_name: '',
      client_ssn: { value: '', disabled: true },
      reporter_first_name: { value: '', disabled: true },
      reporter_last_name: { value: '', disabled: true },
      reporter_email: { value: '', disabled: true },
      reporter_phone_no: '',
      transaction_type: '',
      transaction_sub_type: '',
      trades_placed_flag: 'N',
      senior_Investor_Involved:'N',
      other_suspicious_activity_details:'',
      additional_transaction_details: ''
    });
    this.submitted = false;
    this.getReporterDetails();
    this.getTransactionType();
    this.showSeniorInvestorInvolvedFlag = false;
    this.isVisible=false
    this.IsInvalidAccountNo=false
  }
  onConfirm(): void {
    this.showDialog = false;
  }
  onCloseDialog(): void {
    this.showReferenceNumber = false;
  }
}