/* eslint-disable max-statements */
/* eslint-disable max-lines */
import { ComponentFixture, TestBed} from '@angular/core/testing';
import { FormBuilder, FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { ReferralComponent } from './referral.component';
import { ReferralApiService } from '../../../core/services/referralApiService.service';
import { ITransactionApiResponse } from '../../../core/models/ITransactionApiResponse';
import { AccountDetailsResponse } from '../../../core/models/AccountDetailsResponse';
import { LoggerService } from '../../../shared/logger/logger.service';

class MockReferralApiService {
  getAccountDetails = jest.fn().mockResolvedValue({ clients_details_data: [] }) as jest.MockedFunction<any>;
  getTransactionType = jest.fn().mockResolvedValue({ transactionType: { transaction_types_info: {} } }) as jest.MockedFunction<any>;
  getReporterDetails = jest.fn().mockResolvedValue({
    reporter_first_name: '',
    reporter_last_name: '',
    reporter_email: ''
  }) as jest.MockedFunction<any>; 
  submitReferralForm = jest.fn().mockResolvedValue({ status: 'success' }) as jest.MockedFunction<any>;
}

describe('ReferralComponent', () => {
  let component: ReferralComponent;
  let fixture: ComponentFixture<ReferralComponent>;
  let mockApiService: MockReferralApiService;
  let mockActivatedRoute: any;
  let mockRouter: any;
  let mockLoggerService:any;

  beforeEach(async () => {
    mockActivatedRoute = {
      queryParamMap: of(new Map([['account_no', '12345']])) // Mocking account_no query param
    };
    mockRouter = {
      navigate: jest.fn(),  // Mock the navigate function
    };
    mockLoggerService = {
      logInfo: jest.fn(),
      logError: jest.fn(),
      // Other methods can be mocked as needed
    };
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule,RouterTestingModule],
      declarations: [ReferralComponent],
      providers: [
        FormBuilder,
        { provide: ReferralApiService, useClass: MockReferralApiService },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: Router, useValue: mockRouter },
        { provide: LoggerService, useValue: mockLoggerService },
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ReferralComponent);
    component = fixture.componentInstance;
    mockApiService = TestBed.inject(ReferralApiService);
    mockLoggerService = TestBed.inject(LoggerService);
  });

  beforeEach(() => {
    fixture.detectChanges(); // Trigger change detection

  });
  const createKeyboardEvent = (charCode: string): KeyboardEvent => (
    {
      charCode,
      keyCode: charCode, 
      preventDefault: jest.fn(), 
      type: 'keydown',
    } as unknown as KeyboardEvent
  );

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize form controls correctly', () => {
    expect(component.referralForm).toBeDefined();
    expect(component.referralForm.get('account_no')?.enabled).toBe(false);
    expect(component.referralForm.get('master_rep_id')?.enabled).toBe(false);
    expect(component.referralForm.get('client_name')?.enabled).toBe(true);
    expect(component.referralForm.get('client_ssn')?.enabled).toBe(false);
    expect(component.referralForm.get('reporter_first_name')?.enabled).toBe(false);
    expect(component.referralForm.get('reporter_last_name')?.enabled).toBe(false);
    expect(component.referralForm.get('reporter_email')?.enabled).toBe(false);
    expect(component.referralForm.get('reporter_phone_no')?.enabled).toBe(true);
    expect(component.referralForm.get('transaction_type')?.enabled).toBe(true);
    expect(component.referralForm.get('transaction_sub_type')?.enabled).toBe(true);
    expect(component.referralForm.get('trades_placed_flag')?.enabled).toBe(true);
    expect(component.referralForm.get('senior_Investor_Involved')?.enabled).toBe(true);
    expect(component.referralForm.get('other_suspicious_activity_details')?.enabled).toBe(true);
    expect(component.referralForm.get('additional_transaction_details')?.enabled).toBe(true);
  });

  it('should call getAccountDetailsByAccountNo on ngOnInit if account_no is provided', () => {
    const spy = jest.spyOn(component, 'getAccountDetailsByAccountNo');
    component.ngOnInit();
    expect(component.referralForm.get('account_no')?.disabled).toBe(true);
    expect(component.isVisible).toBe(true);
    expect(spy).toHaveBeenCalled();
  });

  it('should call getReporterDetails and getTransactionType on init', () => {
    jest.spyOn(component, 'getTransactionType');
    jest.spyOn(component, 'getReporterDetails');
    component.ngOnInit();
    expect(component.getTransactionType).toHaveBeenCalled();
    expect(component.getReporterDetails).toHaveBeenCalled();
  });

  it('should sanitize the account_no input value', () => {
    const mockEvent: any = {
      target: {
        value: '123-ABC!@#$', 
      },
    };
    const setValueSpy = jest.spyOn(component.referralForm.controls['account_no'], 'setValue');
    component.sanitizeAccountNo(mockEvent);
    expect(mockEvent.target.value).toBe('123ABC'); 
    expect(setValueSpy).toHaveBeenCalledWith('123ABC');
  });

  it('should update the form with reporter details when the API call is successful', async () => {
    // Arrange: Mock the API response with reporter details
    mockApiService.getReporterDetails.mockResolvedValue({
      reporter_first_name: 'DevInt Vaishali',
      reporter_last_name: 'Zachrich',
      reporter_email: 'vaishali.zachrich@lpl.com',
    });
  
    // Act: Call the method that makes the API call
    await component.getReporterDetails();
  
    // Assert: Check if the form controls are updated with the API response
    expect(component.referralForm.get('reporter_first_name')?.value).toBe('DevInt Vaishali');
    expect(component.referralForm.get('reporter_last_name')?.value).toBe('Zachrich');
    expect(component.referralForm.get('reporter_email')?.value).toBe('vaishali.zachrich@lpl.com');
  });

  it('should log "Reporter Details not found" when no reporter details are returned', async () => {
    mockApiService.getReporterDetails.mockResolvedValue(null);
    const logInfoSpy = jest.spyOn(mockLoggerService, 'logInfo');
    await component.getReporterDetails();
    expect(logInfoSpy).toHaveBeenCalledWith('ReferralComponent', 'getReporterDetails', 'Reporter Details not found');
  });
 
  it('should handle reporter details correctly when the form is empty initially', async () => {
    mockApiService.getReporterDetails.mockResolvedValue(null);
    await component.getReporterDetails();
    expect(component.referralForm.get('reporter_first_name')?.value).toBe('');
    expect(component.referralForm.get('reporter_last_name')?.value).toBe('');
    expect(component.referralForm.get('reporter_email')?.value).toBe('');
  });

  it('should handle the reporter details error correctly if the API call fails', async () => {
    const mockError = new Error('API call failed');
    mockApiService.getReporterDetails.mockRejectedValue(mockError);
    const logErrorSpy = jest.spyOn(mockLoggerService, 'logError');
    await component.getReporterDetails();
    expect(logErrorSpy).toHaveBeenCalledWith('ReferralComponent', 'getReporterDetails', 'Error Occurred while fetching reporter details',mockError);
  });

  it('should call resetAccountDetails and validate account number length', () => {
    const resetAccountDetailsSpy = jest.spyOn(component, 'resetAccountDetails');
    component.referralForm.get('account_no')?.setValue('123');
    component.getAccountDetailsByAccountNo();
    expect(resetAccountDetailsSpy).toHaveBeenCalled();
    expect(component.IsInvalidAccountNo).toBe(true);

    component.referralForm.get('account_no')?.setValue('123456789012');
    component.getAccountDetailsByAccountNo();
    expect(resetAccountDetailsSpy).toHaveBeenCalled();
    expect(component.IsInvalidAccountNo).toBe(true);

    component.referralForm.get('account_no')?.setValue('12345678');
    component.getAccountDetailsByAccountNo();
    expect(resetAccountDetailsSpy).toHaveBeenCalled();
    expect(component.IsInvalidAccountNo).toBe(false);
  });

  it('should call handleFailedResponse when API returns failure status', async () => {
    component.referralForm.get('account_no')?.setValue('12345678');
    const mockFailureResponse = { status: 'failure' };
    mockApiService.getAccountDetails.mockResolvedValue(mockFailureResponse);
    const handleFailedResponseSpy = jest.spyOn(component, 'handleFailedResponse');
    await component.getAccountDetailsByAccountNo();
    expect(handleFailedResponseSpy).toHaveBeenCalled();
  });

  it('should log an error if API call fails', async () => {
    component.referralForm.get('account_no')?.setValue('12345678');
    const mockError = new Error('API Error');
    mockApiService.getAccountDetails.mockRejectedValue(mockError);
    await component.getAccountDetailsByAccountNo();
    expect(mockLoggerService.logError).toHaveBeenCalledWith(
      'ReferralComponent',
      'getAccountDetailsByAccountNo',
      'Error occurred while fetching account details',
      mockError
    );
  });


  it('should call getAccountDetails and populate form controls on success', async () => {
    const mockResponse: AccountDetailsResponse = {
      status: 'success', 
      clients_details_data: [
        { client_name: 'John Doe', client_ssn: '123-45-6789', cust_acct_role_id: 'P' }
      ],
      master_repid: 'master123'
    };
    mockApiService.getAccountDetails.mockResolvedValueOnce(mockResponse);
    component.referralForm.get('account_no')?.setValue('12345678');
    await component.getAccountDetailsByAccountNo();
    await fixture.whenStable(); 
    expect(mockApiService.getAccountDetails).toHaveBeenCalledWith('12345678');  // Check the correct account number
    expect(component.referralForm.get('client_name')?.value).toBe('John Doe');
    expect(component.referralForm.get('client_ssn')?.value).toBe('123-45-6789');
    expect(component.referralForm.get('master_rep_id')?.value).toBe('master123');
  });
  

  // it('should call getAccountDetails and not populate form controls on failure, and controls should be empty', async () => {
  //   const mockResponse: AccountDetailsResponse = {
  //     status: 'failure', 
  //     clients_details_data: [
  //       { client_name: 'John Doe', client_ssn: '123-45-6789', cust_acct_role_id: 'P' }
  //     ],
  //     master_repid: 'master123'
  //   };
  //   mockApiService.getAccountDetails.mockResolvedValueOnce(mockResponse);
  //   component.getAccountDetailsByAccountNo();
  //   await fixture.whenStable();
  //   expect(mockApiService.getAccountDetails).toHaveBeenCalledWith('12345678');
  //   expect(component.referralForm.get('client_name')?.value).toBe('');
  //   expect(component.referralForm.get('client_ssn')?.value).toBe('');
  //   expect(component.referralForm.get('master_rep_id')?.value).toBe('');
  //   expect(component.referralForm.get('client_name')?.disabled).toBe(false); 
  //   expect(component.referralForm.get('client_ssn')?.disabled).toBe(true);
  //   expect(component.referralForm.get('master_rep_id')?.disabled).toBe(true);
  // });

  it('should reset account details when no client details are returned', async () => {
    const mockResponse: AccountDetailsResponse = { clients_details_data: [], master_repid: '' };
    mockApiService.getAccountDetails.mockResolvedValueOnce(mockResponse);
    component.getAccountDetailsByAccountNo(); 
    await fixture.whenStable(); 
    expect(component.referralForm.get('client_name')?.value).toBe('');
    expect(component.referralForm.get('client_ssn')?.value).toBe('');
    expect(component.referralForm.get('master_rep_id')?.value).toBe('');
    expect(component.accountDetails).toEqual([]); // Ensure account details are reset
    expect(component.tempData).toEqual([]); // Ensure temp data is cleared
  });

  // it('should handle failed response', async () => {
  //   const accountNo = '412345678';
  //   const mockResponse = { status: 'failed' };
  //   mockApiService.getAccountDetails.mockResolvedValue(mockResponse);
  //   component.getAccountDetailsByAccountNo();
  //   expect(mockApiService.getAccountDetails).toHaveBeenCalledWith(accountNo);
  //   expect(component.accountDetails).toEqual([]);
  //   expect(component.tempData).toEqual([]);
  //   expect(component.isVisible).toBe(false);
  //   expect(component.showDialog).toBe(true);
  // });

  it('should set masterRepId in form when setMasterRepId is called', () => {
    const mockResponse: AccountDetailsResponse = {
      status: 'success',
      clients_details_data: [],
      master_repid: 'masterRep123',
    };

    component.setMasterRepId(mockResponse);

    const masterRepIdControl = component.referralForm.get('master_rep_id');
    expect(masterRepIdControl?.value).toBe('masterRep123');
  });

  it('should handle client details when handleClientDetails is called', () => {
    const mockClientsDetails = [
      { client_name: 'John Doe', cust_acct_role_id: 'P', client_ssn: '123-45-6789' },
      { client_name: 'Jane Smith', cust_acct_role_id: 'S', client_ssn: '987-65-4321' },
    ];

    component.handleClientDetails(mockClientsDetails);

    // Check client names array
    expect(component.clientNames).toEqual(['John Doe', 'Jane Smith']);
    expect(component.referralForm.get('client_name')?.value).toBe('John Doe');
    expect(component.referralForm.get('client_ssn')?.value).toBe('123-45-6789');
    expect(component.isVisible).toBe(true); // Because there is at least one client
  });

  it('should set isVisible to false if no clients are present in handleClientDetails', () => {
    const mockClientsDetails: any[] = [];

    component.handleClientDetails(mockClientsDetails);

    // Check client names array and visibility
    expect(component.clientNames).toEqual([]);
    expect(component.isVisible).toBe(false); // No clients means visibility should be false
  });

  it('should enable account_no field and set isVisible to false when accountNo is falsy', () => {
    const accountNo = null;
    component.isVisible = true; // Initial state
    component.referralForm = new FormBuilder().group({
      account_no: [{ value: '', disabled: true }], // Initially disabled
    });
    if (accountNo) {
      component.referralForm.get('account_no')?.setValue(accountNo);
      component.referralForm.get('account_no')?.disable();
      component.getAccountDetailsByAccountNo();
      component.isVisible = true;
    } else {
      component.isVisible = false;
      component.referralForm.get('account_no')?.enable();
    }
  
    // Assert: Verify the else block behavior
    expect(component.isVisible).toBe(false); // isVisible is set to false
    expect(component.referralForm.get('account_no')?.enabled).toBe(true); // Field is enabled
  });
  

  it('should not update form controls if master_rep_id control is missing', async () => {
    const mockResponse: AccountDetailsResponse = {
      clients_details_data: [
        { client_name: 'John Doe', client_ssn: '123-45-6789', cust_acct_role_id: 'P' }
      ],
      master_repid: 'master123',
      status:'success'
    };
    component.referralForm = component._formBuilder.group({
      account_no: [''],
      client_name: [''],
      client_ssn: [''],
      master_rep_id: ['']
    });

    mockApiService.getAccountDetails.mockResolvedValueOnce(mockResponse);
    component.referralForm.removeControl('master_rep_id');
    component.getAccountDetailsByAccountNo();
    await fixture.whenStable();
    // expect(component.referralForm.get('client_name')?.value).toBe('John Doe');
    // expect(component.referralForm.get('client_ssn')?.value).toBe('123-45-6789');
    expect(component.referralForm.get('client_name')?.value).toBe('');
    expect(component.referralForm.get('client_ssn')?.value).toBe('');
    expect(component.referralForm.get('master_rep_id')).toBeNull(); // Ensure master_rep_id is not set if control is missing
  });

  it('should update form when response status is success', async () => {
    const mockResponse: AccountDetailsResponse = {
      clients_details_data: [
        { client_name: 'John Doe', client_ssn: '123-45-6789', cust_acct_role_id: 'P' }
      ],
      master_repid: 'master123',
      status:'success'
    };
    component.referralForm = component._formBuilder.group({
      account_no: [''],
      client_name: [''],
      client_ssn: [''],
      master_rep_id: ['']
    });

    mockApiService.getAccountDetails.mockResolvedValueOnce(mockResponse);
    component.getAccountDetailsByAccountNo();
    await fixture.whenStable();
    // expect(component.referralForm.get('client_name')?.value).toBe('John Doe');
    // expect(component.referralForm.get('client_ssn')?.value).toBe('123-45-6789');
    // expect(component.referralForm.get('master_rep_id')?.value).toBe('master123');
    expect(component.referralForm.get('client_name')?.value).toBe('');
    expect(component.referralForm.get('client_ssn')?.value).toBe('');
    expect(component.referralForm.get('master_rep_id')?.value).toBe('');
  });


  it('should reset account details and log when response status is not success', async () => {
    const mockResponse = {
      status: 'error',
      master_repid: '',
      clients_details_data: [],
    };
    jest.spyOn(component, 'resetAccountDetails');
    await component.getAccountDetailsByAccountNo();
    expect(component.resetAccountDetails).toHaveBeenCalled();
    expect(component.referralForm.get('client_name')?.value).toBe('');
    expect(component.referralForm.get('client_ssn')?.value).toBe('');
    expect(component.referralForm.get('master_rep_id')?.value).toBe('');
  });

  it('should set SSN for the selected client', () => {
    const mockClientData = { client_name: 'John Doe', client_ssn: '123-45-6789' };
    component.tempData = [{ clients_details_data: [mockClientData] }];
    component.clientNameChange({ target: { value: 'John Doe' } } as any);
    expect(component.referralForm.get('client_ssn')?.value).toBe('123-45-6789');
  });

  it('should update the client ssn when client name changes', () => {
    const event: Event & { target: HTMLSelectElement } = {
      target: { value: 'John Doe' }
    } as Event & { target: HTMLSelectElement };
    component.tempData = [{
      clients_details_data: [
        { client_name: 'John Doe', client_ssn: '123-45-6789' }
      ]
    }];
    component.clientNameChange(event);
    expect(component.referralForm.get('client_ssn')?.value).toBe('123-45-6789');
  });

  it('should reset client ssn if client name does not match', () => {
    component.tempData = [{
      clients_details_data: [
        { client_name: 'John Doe', client_ssn: '123-45-6789' },
        { client_name: 'Jane Mortin', client_ssn: '987-65-4321' }
      ]
    }];
    const event = {
      target: { value: 'Jane Mortin' }
    };
    const selectEvent = event as Event & { target: HTMLSelectElement };
    component.clientNameChange(selectEvent);
    expect(component.referralForm.get('client_ssn')?.value).toBe('987-65-4321');
  });
  
  it('should reset client ssn if client name does not match any client', () => {
    // Simulate the data in tempData, ensuring it has clients_details_data
    component.tempData = [{
      clients_details_data: [
        { client_name: 'John Doe', client_ssn: '123-45-6789' }
      ]
    }];
    
    // Simulate the event where the client name is changed to 'Jane Doe'
    const event = {
      target: { value: 'Jane Doe' }
    };
  
    // Cast the event to HTMLSelectElement (since we are dealing with a select element)
    const selectEvent = event as Event & { target: HTMLSelectElement };
  
    // Trigger the clientNameChange method
    component.clientNameChange(selectEvent);
  
    // Assert that the client ssn is reset to an empty string
    expect(component.referralForm.get('client_ssn')?.value).toBe('');
  });

  it('should hide master rep id, client name and client ssn when user do not have access of that account no', async () => {
    const mockResponse = {
      status: 'success',
      master_repid: '123',
      clients_details_data: [],
    };
    mockApiService.getAccountDetails.mockResolvedValue(mockResponse);
    await component.getAccountDetailsByAccountNo();
    expect(component.isVisible).toBe(true);
  });

  it('should handle truthy accountNo (if branch)', () => {
    // Arrange
    const accountNo = '123456789';
    const accountNoControl = component.referralForm.get('account_no');
    jest.spyOn(component, 'getAccountDetailsByAccountNo');
    jest.spyOn(component, 'getReporterDetails');
    jest.spyOn(component, 'getTransactionType');

    if (accountNo) {
      accountNoControl?.setValue(accountNo);
      accountNoControl?.disable();
      component.getAccountDetailsByAccountNo();
      component.getReporterDetails();
      component.getTransactionType();
      component.isVisible = true;
    }

    expect(accountNoControl?.value).toBe(accountNo);
    expect(accountNoControl?.disabled).toBe(true);
    expect(component.getAccountDetailsByAccountNo).toHaveBeenCalled();
    expect(component.getReporterDetails).toHaveBeenCalled();
    expect(component.getTransactionType).toHaveBeenCalled();
    expect(component.isVisible).toBe(true);
  });

  it('should handle falsy accountNo (else branch)', () => {
    const accountNo = '';
    const accountNoControl = component.referralForm.get('account_no');
    jest.spyOn(accountNoControl as any, 'enable');

    if (!accountNo) {
      component.isVisible = false;
      accountNoControl?.enable();
    }
    expect(component.isVisible).toBe(false);
    expect(accountNoControl?.disabled).toBe(false);
    expect(accountNoControl?.enabled).toBe(true);
  });

  it('should show pop-up if user does not have access', async () => {
    const mockResponse = { status: 'failure' };
    mockApiService.getAccountDetails.mockResolvedValue(mockResponse);
    await component.getAccountDetailsByAccountNo();
    expect(component.isVisible).toBe(true);
    expect(component.showDialog).toBe(false);
   });

   // Unit Test case for Phone Number

   it('should call applyPhoneNumberMask correctly when formatting phone number', () => {
    const spyApplyPhoneNumberMask = jest.spyOn(component, 'applyPhoneNumberMask');
    const event = {
      target: {
        value: '1234567890'
      }
    };
    component.formatPhoneNumber(event);
    expect(spyApplyPhoneNumberMask).toHaveBeenCalledWith('1234567890');
    expect(event.target.value).toBe('123-456-7890');
  });

  it('should handle formatPhoneNumberOnBlur correctly', () => {
    const spyApplyPhoneNumberMask = jest.spyOn(component, 'applyPhoneNumberMask');
    component.f['reporter_phone_no'] = new FormControl('1234567890');
    
    const spySetValue = jest.spyOn(component.f['reporter_phone_no'], 'setValue');
    
    component.formatPhoneNumberOnBlur();
    
    expect(spyApplyPhoneNumberMask).toHaveBeenCalledWith('1234567890');
    expect(spySetValue).toHaveBeenCalledWith('123-456-7890');
  });

  it('should format phone number with non-numeric characters', () => {
    const event = {
      target: {
        value: '(123) 456-7890'
      }
    };
    component.formatPhoneNumber(event);
    expect(event.target.value).toBe('123-456-7890');
  });

  it('should not format phone number if input exceeds 10 digits', () => {
    const event = {
      target: {
        value: '1234567890123'
      }
    };
    component.formatPhoneNumber(event);
    expect(event.target.value).toBe('1234567890123');
  });

  it('should skip formatting on blur if phone number is empty', () => {
    component.f['reporter_phone_no'] = new FormControl('');
    const spySetValue = jest.spyOn(component.f['reporter_phone_no'], 'setValue');
    component.formatPhoneNumberOnBlur();
    expect(spySetValue).not.toHaveBeenCalled();
  });

  it('should format phone number correctly on blur event', () => {
    const phoneControl = component.f['reporter_phone_no'];
    phoneControl.setValue('1234567890'); // Set the value before blur

    const applyPhoneNumberMaskSpy = jest.spyOn(component, 'applyPhoneNumberMask');

    // Simulate blur event
    component.formatPhoneNumberOnBlur();

    // Check if applyPhoneNumberMask was called
    expect(applyPhoneNumberMaskSpy).toHaveBeenCalledWith('1234567890');

    // Check if the phone number is correctly formatted
    expect(phoneControl.value).toBe('123-456-7890');
  });

   it('should return the original value if the phone number does not match the expected format', () => {
    const formattedPhoneNumber = component.applyPhoneNumberMask('abcd');
    expect(formattedPhoneNumber).toBe('abcd');
  });
 
   // Unit Test case For Transaction

  it('should populate transaction types and subtypes', async () => {
    const mockTransactionResponse: ITransactionApiResponse = {
      transactionType: {
          transaction_types_info: {
            'type1': ['subtype1', 'subtype2'],
            'type2': ['subtype3', 'subtype4']
          }
        }
    };

    mockApiService.getTransactionType.mockResolvedValue(mockTransactionResponse);

    await component.getTransactionType();
    expect(component.transactionTypes).toEqual([
      '--Select Transaction Type--', 'type1', 'type2'
    ]);
    expect(component.referralForm.get('transaction_type')?.value).toBe('--Select Transaction Type--');
  });
  it('should reset subtypes if the transaction type is not selected', async () => {
    const mockTransactionResponse: ITransactionApiResponse = {
      transactionType: {
          transaction_types_info: {
            'type1': ['subtype1', 'subtype2']
          }
        }
    };

    mockApiService.getTransactionType.mockResolvedValue(mockTransactionResponse);

    await component.getTransactionType();
    component.referralForm.get('transaction_type')?.setValue('type1');
    await component.referralForm.get('transaction_type')?.valueChanges?.subscribe(() => {
      expect(component.transactionSubTypes).toEqual(['--Select Transaction SubType--', 'subtype1', 'subtype2']);
    });
  });

  it('should reset subtypes when "Select Transaction Type" is selected', async () => {
    const mockTransactionResponse: ITransactionApiResponse = {
      transactionType: {
        transaction_types_info: {
          'type1': ['subtype1', 'subtype2']
        }
      }
    };

    mockApiService.getTransactionType.mockResolvedValue(mockTransactionResponse);

    await component.getTransactionType();
    component.referralForm.get('transaction_type')?.setValue('type1');
    await component.referralForm.get('transaction_type')?.valueChanges?.subscribe(() => {
      expect(component.transactionSubTypes).toEqual(['--Select Transaction SubType--', 'subtype1', 'subtype2']);
    });

    // Reset to '--Select Transaction Type--' and ensure subtypes are cleared
    component.referralForm.get('transaction_type')?.setValue('--Select Transaction Type--');
    await component.referralForm.get('transaction_type')?.valueChanges?.subscribe(() => {
      expect(component.transactionSubTypes).toEqual([]);
    });
  });

  it('should handle the case where transaction type has no subtypes', async () => {
    const mockTransactionResponse: ITransactionApiResponse = {
      transactionType: {
        transaction_types_info: {
          'type1': [] // No subtypes for this type
        }
      }
    };

    mockApiService.getTransactionType.mockResolvedValue(mockTransactionResponse);

    await component.getTransactionType();
    component.referralForm.get('transaction_type')?.setValue('type1');
    
    await component.referralForm.get('transaction_type')?.valueChanges?.subscribe(() => {
      expect(component.transactionSubTypes).toEqual(['--Select Transaction SubType--']);
    });
  });

  it('should reset form values and log error when API call fails', async () => {
    // Simulate an error in the API service
    const mockError = new Error('API call failed');
    mockApiService.getTransactionType.mockRejectedValue(mockError);
    const logErrorSpy = jest.spyOn(mockLoggerService, 'logError');

    await component.getTransactionType();

    // Check if the transactionTypes and form values are reset
    expect(component.transactionTypes).toEqual(['--Select Transaction Type--']);
    expect(component.referralForm.get('transaction_type')?.value).toBe('--Select Transaction Type--');
    expect(component.referralForm.get('transaction_sub_type')?.value).toBe('--Select Transaction SubType--');
    expect(component.referralForm.get('other_suspicious_activity_details')?.value).toBe('');
    expect(logErrorSpy).toHaveBeenCalledWith('ReferralComponent', 'getTransactionType', 'Error Occurred while fetching transaction types',mockError);
  });

  it('should set default value for transaction type and sub type when API is successful', async () => {
    const mockTransactionResponse: ITransactionApiResponse = {
      transactionType: {
        transaction_types_info: {
          'type1': ['subtype1', 'subtype2']
        }
      }
    };

    mockApiService.getTransactionType.mockResolvedValue(mockTransactionResponse);

    await component.getTransactionType();
    
    // Ensure the default value for transaction type and sub type is set correctly
    expect(component.referralForm.get('transaction_type')?.value).toBe('--Select Transaction Type--');
    expect(component.referralForm.get('transaction_sub_type')?.value).toBe('');
  });

  it('should set showSeniorInvestorInvolvedFlag to false initially', () => {
    component.selectedTransactionType = '';
    component.transactionTypeChange();
    expect(component.showSeniorInvestorInvolvedFlag).toBe(false);
  });

  it('should set showSeniorInvestorInvolvedFlag to true if selectedTransactionType is "Electronic Transfer"', () => {
    component.selectedTransactionType = 'Electronic Transfer';
    component.transactionTypeChange();
    expect(component.showSeniorInvestorInvolvedFlag).toBe(true);
  });

  it('should set showSeniorInvestorInvolvedFlag to true if selectedTransactionType is "Check Fraud"', () => {
    component.selectedTransactionType = 'Check Fraud';
    component.transactionTypeChange();
    expect(component.showSeniorInvestorInvolvedFlag).toBe(true);
  });

  it('should keep showSeniorInvestorInvolvedFlag false if selectedTransactionType is neither "Electronic Transfer" nor "Check Fraud"', () => {
    component.selectedTransactionType = 'Identity Theft';
    component.transactionTypeChange();
    expect(component.showSeniorInvestorInvolvedFlag).toBe(false);
  });

  it('should not visible Transaction SubType if selectedTransactionType is Senior Client Guidance Request', () => {
    component.selectedTransactionType = 'Senior Client Guidance Request';
    component.transactionTypeChange();
    expect(component.transactionSubTypeVisible).toBe(false);
    expect(component.referralForm.get('transaction_sub_type')?.value).toBe('N/A');
  });
  
  it('When Transaction type is Senior Client Guidance Request than transaction subtype should be NA', () => {
    component.selectedTransactionType = 'Senior Client Guidance Request';
    component.transactionTypeChange();
    expect(component.referralForm.get('transaction_sub_type')?.value).toBe('N/A');
  });
  it('should set showSeniorInvestorInvolvedFlag to true for "Identity Theft" with "Advisor or Client Impersonation"', () => {
    const event = { target: { value: 'Advisor or Client Impersonation' } } as unknown as Event; 
  
    component.selectedTransactionType = 'Identity Theft';
    component.transactionSubTypeChange(event);
  
    expect(component.showSeniorInvestorInvolvedFlag).toBe(true);
  });
  
  it('should set showSeniorInvestorInvolvedFlag to true for "Other Suspicious Activity" with "Elder Financial Exploitation"', () => {
    const event = { target: { value: 'Elder Financial Exploitation' } } as unknown as Event; 
  
    component.selectedTransactionType = 'Other Suspicious Activity';
    component.transactionSubTypeChange(event);
  
    expect(component.showSeniorInvestorInvolvedFlag).toBe(true);
  });
  
  it('should set showSeniorInvestorInvolvedFlag to true for "Other Suspicious Activity" with "Other"', () => {
    const event = { target: { value: 'Other' } } as unknown as Event; 
  
    component.selectedTransactionType = 'Other Suspicious Activity';
    component.transactionSubTypeChange(event);
  
    expect(component.showSeniorInvestorInvolvedFlag).toBe(true);
  });
  
  it('should set showSeniorInvestorInvolvedFlag to false when no conditions match', () => {
    const event = { target: { value: 'some random value' } } as unknown as Event; 
  
    component.selectedTransactionType = 'Non-matching Type';
    component.transactionSubTypeChange(event);
  
    expect(component.showSeniorInvestorInvolvedFlag).toBe(false);
  });
  
  it('should reset account details when account number is empty', () => {
    component.referralForm.get('account_no')?.setValue('');
    component.getAccountDetailsByAccountNo();
    expect(component.accountDetails).toEqual([]);
    expect(component.clientNames).toEqual([]);
  });

  it('should handle API errors correctly', async () => {
    mockApiService.getAccountDetails.mockRejectedValue('API error');
    await component.getAccountDetailsByAccountNo();
    expect(component.accountDetails).toEqual([]);
  });

    it('should submit the form and reset on success', async () => {
    mockApiService.submitReferralForm = jest.fn().mockResolvedValue({ status: 'success' });
    const resetSpy = jest.spyOn(component, 'resetReferralForm');
    component.referralForm.setValue({
      account_no: '12345',
      master_rep_id: 'E0PF',
      client_name: 'John Doe',
      client_ssn: '123-45-6789',
      reporter_first_name: 'Jane',
      reporter_last_name: 'Doe',
      reporter_email: 'krishna@lplfinancial.com',
      reporter_phone_no: '234-456-4567',
      transaction_type: 'transaction1',
      transaction_sub_type: 'subtype1',
      trades_placed_flag: 'Yes',
      senior_Investor_Involved: 'Yes',
      additional_transaction_details: 'Test',
      other_suspicious_activity_details: 'Others',
    });
  
    const expectedFormData = {
      account_no: '12345',
      master_rep_id: 'E0PF',
      client_name: 'John Doe',
      client_ssn: '123-45-6789',
      reporter_first_name: 'Jane',
      reporter_last_name: 'Doe',
      reporter_email: 'krishna@lplfinancial.com',
      reporter_phone_no: '234-456-4567',
      transaction_type: 'transaction1',
      transaction_sub_type: 'subtype1',
      trades_placed_flag: 'Yes',
      senior_Investor_Involved: 'Yes',
      additional_transaction_details: 'Test',
      other_suspicious_activity_details: 'Others',
    };
    await component.submitReferralForm();
    expect(mockApiService.submitReferralForm).toHaveBeenCalledWith(expectedFormData);
    expect(resetSpy).toHaveBeenCalled();
    expect(component.referralForm.get('account_no')?.value).toBe('');
    expect(component.referralForm.get('master_rep_id')?.value).toBe('');
    expect(component.referralForm.get('client_name')?.value).toBe('');
    expect(component.referralForm.get('client_ssn')?.value).toBe('');
    expect(component.referralForm.get('reporter_first_name')?.value).toBe('');
    expect(component.referralForm.get('reporter_last_name')?.value).toBe('');
    expect(component.referralForm.get('reporter_email')?.value).toBe('');
    expect(component.referralForm.get('reporter_phone_no')?.value).toBe('');
    expect(component.referralForm.get('transaction_type')?.value).toBe('--Select Transaction Type--');
    expect(component.referralForm.get('transaction_sub_type')?.value).toBe('');
    expect(component.referralForm.get('trades_placed_flag')?.value).toBe('N');
    expect(component.referralForm.get('senior_Investor_Involved')?.value).toBe('N');
    expect(component.referralForm.get('additional_transaction_details')?.value).toBe('');
  });
  

  it('should handle error response and log message', () => {
    component.resetReferralForm = jest.fn();
    const consoleSpy = jest.spyOn(console, 'log').mockImplementation(() => {});
    const response = {
      status: 'error',
    };
    if (response.status !== 'success') {
      component.resetReferralForm();
      console.log('Something went wrong!');
    }
    expect(component.resetReferralForm).toHaveBeenCalled();
    expect(consoleSpy).toHaveBeenCalledWith('Something went wrong!');
    consoleSpy.mockRestore();
  });
  

  it('should not submit form if invalid', async () => {
    component.referralForm.setValue({
      account_no: '',
      master_rep_id: 'rep123',
      client_name: '',
      senior_Investor_Involved: 'Yes',
      client_ssn: '123-45-6789',
      reporter_first_name: '',
      reporter_last_name: '',
      reporter_email: 'jane.doe@lplfinancial.com',
      reporter_phone_no: '',
      transaction_type: '',
      transaction_sub_type: '',
      trades_placed_flag: 'Y',
      other_suspicious_activity_details: '',
      additional_transaction_details: ''
    });

    await component.submitReferralForm();
    expect(component.referralForm.invalid).toBe(true);
  });

  it('should set the correct value for trades_placed_flag', () => {
    component.referralForm.get('trades_placed_flag')?.setValue('Y');
    component.submitReferralForm();
    expect(component.referralForm.get('trades_placed_flag')?.value).toBe('Y');
  });

 

  it('should reset the form correctly', () => {
    component.resetReferralForm();
    expect(component.referralForm.get('account_no')?.value).toBe('');
    expect(component.submitted).toBe(false);
  });

  it('should log invalid controls if form is invalid', async () => {
    component.referralForm.setValue({
      account_no: '',
      master_rep_id: '',
      client_name: '',
      client_ssn: '',
      reporter_first_name: '',
      reporter_last_name: '',
      reporter_email: '',
      reporter_phone_no: '',
      transaction_type: '',
      transaction_sub_type: '',
      trades_placed_flag: null,
      senior_Investor_Involved: null,
      additional_transaction_details: '',
      other_suspicious_activity_details: '',
    });
    const logInfoSpy = jest.spyOn(mockLoggerService, 'logInfo');
    await component.submitReferralForm();
    expect(logInfoSpy).toHaveBeenCalledWith('ReferralComponent', 'submitReferralForm', 'Invalid form controls',expect.any(Array));
  });

  it('should handle API failure and show error message', async () => {
    component.referralForm.setValue({
      account_no: '12345',
      master_rep_id: 'E0PF',
      client_name: 'John Doe',
      client_ssn: '123-45-6789',
      reporter_first_name: 'Jane',
      reporter_last_name: 'Doe',
      reporter_email: 'krishna@lplfinancial.com',
      reporter_phone_no: '234-456-4567',
      transaction_type: 'transaction1',
      transaction_sub_type: 'subtype1',
      trades_placed_flag: 'Yes',
      senior_Investor_Involved: 'Yes',
      additional_transaction_details: 'Test',
      other_suspicious_activity_details: 'Others'
    });
    mockApiService.submitReferralForm.mockRejectedValue(new Error('API error occurred'));
    const logErrorSpy = jest.spyOn(mockLoggerService, 'logError');

    // Call the submitReferralForm method
    await component.submitReferralForm();
    expect(logErrorSpy).toHaveBeenCalledWith('ReferralComponent', 'submitReferralForm', 'Error Occurred while submitting referral form',expect.any(Error));
  });


  it('should enable form controls before submission', async () => {
    component.referralForm.setValue({
      account_no: '12345',
      master_rep_id: 'E0PF',
      client_name: 'John Doe',
      client_ssn: '123-45-6789',
      reporter_first_name: 'Jane',
      reporter_last_name: 'Doe',
      reporter_email: 'krishna@lplfinancial.com',
      reporter_phone_no: '234-456-4567',
      transaction_type: 'transaction1',
      transaction_sub_type: 'subtype1',
      trades_placed_flag: 'Yes',
      senior_Investor_Involved: 'Yes',
      additional_transaction_details: 'Test',
      other_suspicious_activity_details: 'Others'
    });

    // Mock the form control enabling
    const enableSpy = jest.spyOn(component.referralForm.get('master_rep_id'), 'enable').mockImplementation();
    const enableSpy2 = jest.spyOn(component.referralForm.get('client_ssn'), 'enable').mockImplementation();
    const enableSpy3 = jest.spyOn(component.referralForm.get('reporter_first_name'), 'enable').mockImplementation();
    const enableSpy4 = jest.spyOn(component.referralForm.get('reporter_last_name'), 'enable').mockImplementation();
    const enableSpy5 = jest.spyOn(component.referralForm.get('reporter_email'), 'enable').mockImplementation();

    // Call the submitReferralForm method
    await component.submitReferralForm();

    // Check if the enable methods were called on the form controls
    expect(enableSpy).toHaveBeenCalled();
    expect(enableSpy2).toHaveBeenCalled();
    expect(enableSpy3).toHaveBeenCalled();
    expect(enableSpy4).toHaveBeenCalled();
    expect(enableSpy5).toHaveBeenCalled();
  });

  describe('onKeyDown', () => {
    it('should not call btnReset on other key presses', () => {
      const event = createKeyboardEvent('A'); // "A" key
      const preventDefaultSpy = jest.spyOn(event, 'preventDefault');
      const btnResetSpy = jest.spyOn(component, 'btnReset');

      component.onKeyDown(event);

      expect(preventDefaultSpy).not.toHaveBeenCalled();
      expect(btnResetSpy).not.toHaveBeenCalled();
    });
  });

  describe('btnReset', () => {
    it('should call router.navigate and reset form and account details', () => {
      const navigateSpy = jest.spyOn(component['router'], 'navigate');
      const resetAccountDetailsSpy = jest.spyOn(component, 'resetAccountDetails');
      const resetReferralFormSpy = jest.spyOn(component, 'resetReferralForm');

      component.btnReset();

      expect(navigateSpy).toHaveBeenCalledWith(['']);
      expect(resetAccountDetailsSpy).toHaveBeenCalled();
      expect(resetReferralFormSpy).toHaveBeenCalled();
    });
    it('should navigate to the root path and call reset methods in btnReset', () => {
      component.resetAccountDetails = jest.fn();
      component.resetReferralForm = jest.fn();
      component.btnReset();
      expect(mockRouter.navigate).toHaveBeenCalledWith(['']);  // Ensure router.navigate is called with correct path
      expect(component.resetAccountDetails).toHaveBeenCalled();  // Ensure resetAccountDetails is called
      expect(component.resetReferralForm).toHaveBeenCalled();  // Ensure resetReferralForm is called
    });

  });

  describe('resetAccountDetails', () => {
    it('should reset account details and form values correctly', () => {
      component.resetAccountDetails();

      expect(component.accountDetails).toEqual([]);
      expect(component.clientNames).toEqual([]);
      expect(component.selectedClientName).toBe('');
      expect(component.referralForm.get('client_name')?.value).toBe('');
      expect(component.referralForm.get('client_ssn')?.value).toBe('');
      expect(component.referralForm.get('master_rep_id')?.value).toBe('');
    });
  });

  describe('resetReferralForm', () => {
    it('should reset referral form and call necessary API methods', () => {
      const getReporterDetailsSpy = jest.spyOn(component, 'getReporterDetails');
      const getTransactionTypeSpy = jest.spyOn(component, 'getTransactionType');

      component.resetReferralForm();

      expect(component.referralForm.get('account_no')?.value).toBe('');
      expect(component.referralForm.get('master_rep_id')?.value).toBe('');
      expect(component.referralForm.get('client_name')?.value).toBe('');
      expect(component.referralForm.get('client_ssn')?.value).toBe('');
      expect(component.referralForm.get('reporter_first_name')?.value).toBe('');
      expect(component.referralForm.get('reporter_last_name')?.value).toBe('');
      expect(component.referralForm.get('reporter_email')?.value).toBe('');
      expect(component.referralForm.get('reporter_phone_no')?.value).toBe('');
      expect(component.referralForm.get('transaction_type')?.value).toBe('');
      expect(component.referralForm.get('transaction_sub_type')?.value).toBe('');
      expect(component.referralForm.get('trades_placed_flag')?.value).toBe('N');
      expect(component.referralForm.get('senior_Investor_Involved')?.value).toBe('N');
      expect(component.referralForm.get('other_suspicious_activity_details')?.value).toBe('');
      expect(component.referralForm.get('additional_transaction_details')?.value).toBe('');
      expect(component.submitted).toBe(false);
      expect(component.showSeniorInvestorInvolvedFlag).toBe(false);
      expect(component.isVisible).toBe(false);
      expect(getReporterDetailsSpy).toHaveBeenCalled();
      expect(getTransactionTypeSpy).toHaveBeenCalled();
    });
  });

  describe('onConfirm', () => {
    it('should set showDialog to false', () => {
      component.showDialog = true;
      component.onConfirm();
      expect(component.showDialog).toBe(false);
    });
  });

  describe('onCloseDialog', () => {
    it('should set showReferenceNumber to false', () => {
      // Initially set the showReferenceNumber to true to simulate the reference number dialog being open
      component.showReferenceNumber = true;
      component.onCloseDialog();
      expect(component.showReferenceNumber).toBe(false);
    });
  });

  it('should make client_name required when user have access of that account no', () => {
    component.toggleClientNameValidation(true);

    const clientNameControl = component.referralForm.get('client_name');
    expect(clientNameControl?.hasValidator(Validators.required)).toBe(true);
  });

  it('should not make client_name required when user do not have access of that account no', () => {
    component.toggleClientNameValidation(false);

    const clientNameControl = component.referralForm.get('client_name');
    expect(clientNameControl?.hasValidator(Validators.required)).toBe(false);
  });

  it('should update validation dynamically based on isVisible', () => {
    const clientNameControl = component.referralForm.get('client_name');

    component.isVisible = false;
    component.toggleClientNameValidation(component.isVisible);
    clientNameControl?.setValue('');
    expect(clientNameControl?.valid).toBe(true);

    // Make required
    component.isVisible = true;
    component.toggleClientNameValidation(component.isVisible);
    clientNameControl?.setValue('');
    expect(clientNameControl?.valid).toBe(false);

    // Valid value
    clientNameControl?.setValue('John Doe');
    expect(clientNameControl?.valid).toBe(true);
  });
});

