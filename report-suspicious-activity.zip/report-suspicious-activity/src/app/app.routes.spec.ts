import { TestBed } from '@angular/core/testing';
import { RouterModule, Routes } from '@angular/router';
import { ReferralComponent } from './feature/components/referral/referral.component';
import { appRoutes, AppRoutingModule } from './app.routes';

describe('AppRoutingModule', () => {

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AppRoutingModule], 
    });
  });

  it('should create the AppRoutingModule', () => {
    const module = TestBed.inject(AppRoutingModule);
    expect(module).toBeTruthy();
  });

  it('should have correct routes configured', () => {
    const routes: Routes = appRoutes;

    expect(routes[0].path).toBe('report-suspicious-activity/:account_no');
    expect(routes[0].component).toBe(ReferralComponent);

    expect(routes[1].path).toBe('referral/:account_no');
    expect(routes[1].component).toBe(ReferralComponent);

    expect(routes[2].path).toBe('referral');
    expect(routes[2].component).toBe(ReferralComponent);
  });

  it('should correctly import and export RouterModule', () => {
    const module = TestBed.inject(AppRoutingModule);
    expect(module).toBeTruthy();
    const routerModule = TestBed.inject(RouterModule);
    expect(routerModule).toBeDefined();
  });

});
